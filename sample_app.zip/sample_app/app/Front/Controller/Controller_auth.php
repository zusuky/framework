<?php

class Controller_auth extends Controller {

	use ControllerTrait;

	/**
	 * 表示
	 */
	public function action_index(): void {
		try {

			$view = View::forge();
			$view->display('auth/index.tpl');

		} catch (Throwable $e) {
			fatalLog('想定外の例外が発生しました。', $e);
			$this->showSystemError();
		}
	}

	/**
	 * ログイン
	 */
	public function action_login(): void {
		try {

			$errors = $this->validation();

			if (count($errors) > 0) {
				warnLog('validationエラーです。' . print_r($errors, true));
				$view = View::forge();
				$view->assignArr(Post::get());
				$view->assign('errors', $errors);
				$view->display('auth/index.tpl');
				return;
			}

			DB::beginTransaction();

			$result = Auth::login(Post::get('login_id'), Post::get('password'));

			if (!$result) {
				$errors = ['unauthorized' => Message::get('errorUnauthorized')];
				warnLog('validationエラーです。' . print_r($errors, true));
				DB::rollback();
				$view = View::forge();
				$view->assignArr(Post::get());
				$view->assign('errors', $errors);
				$view->display('auth/index.tpl');
				return;
			}

			DB::commit();

			Html::redirect(Html::url());

		} catch (Throwable $e) {
			fatalLog('想定外の例外が発生しました。', $e);
			$this->showSystemError();
		}
	}

	/**
	 * ログアウト
	 */
	public function action_logout(): void {
		try {

			Auth::logout();

			Html::redirect(Html::url());

		} catch (Throwable $e) {
			fatalLog('想定外の例外が発生しました。', $e);
			$this->showSystemError();
		}
	}

	/**
	 * validation
	 *
	 * @return   array
	 */
	private function validation(): array
	{
		$validation = Validation::forge();

		// Login ID
		$validation->addItem('login_id', Post::get('login_id'))
			->addRule('required', Message::get('requiredSelect', ['Login ID']));

		// Password
		$validation->addItem('password', Post::get('password'))
			->addRule('required', Message::get('required', ['Password']));

		return $validation->run();
	}

}
