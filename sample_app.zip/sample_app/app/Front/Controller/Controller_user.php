<?php

class Controller_user extends Controller
{

    use ControllerTrait;

    /**
     * 登録画面表示
     */
    public function action_create() : void
    {
        try {

            $view = View::forge();
            $view->display('user/create.tpl');

        } catch (Throwable $e) {
            fatalLog('想定外の例外が発生しました。', $e);
            $this->showSystemError();
        }
    }

    /**
     * 登録
     */
    public function action_create_save() : void
    {
        try {

            $errors = $this->validation();
            if (count($errors) > 0) {
                warnLog('validationエラーです。' . print_r($errors, true));
                $view = View::forge();
                $view->assignArr(Post::get());
                $view->assign('errors', $errors);
                $view->display('user/create.tpl');
                return;
            }

            $model_user = Model_user::forge();
            $model_user_profile = Model_user_profile::forge();

            DB::beginTransaction();

            $same_login_id_user = $model_user->findByLoginId(Post::get('login_id'));

            if (count($same_login_id_user) > 0) {
                $errors = ['conflict' => 'A user with the same login ID already exists.'];
                warnLog('validationエラーです。' . print_r($errors, true));
                DB::rollback();
                $view = View::forge();
                $view->assignArr(Post::get());
                $view->assign('errors', $errors);
                $view->display('user/create.tpl');
                return;
            }

            $condition = [
                'email' => Post::get('email'),
            ];

            $same_email_users = $model_user->where($condition);

            if (count($same_email_users) > 0) {
                $errors = ['conflict' => 'A user with the same email already exists.'];
                warnLog('validationエラーです。' . print_r($errors, true));
                DB::rollback();
                $view = View::forge();
                $view->assignArr(Post::get());
                $view->assign('errors', $errors);
                $view->display('user/create.tpl');
                return;
            }

            $user_id = UuidCreator::create();
            $user = [
                'user_id' => $user_id,
                'login_id' => Post::get('login_id'),
                'password' => Crypt::encrypt(Post::get('password')),
                'status' => UserStatusConst::VALID,
                'created_id' => Auth::getUserId(),
                'updated_id' => Auth::getUserId(),
            ];

            $model_user->create($user);

            $user_profile_id = UuidCreator::create();
            $full_name = $this->creteFullName(Post::get('last_name'), Post::get('middle_name'), Post::get('first_name'));
            $custom_profile = json_encode([
                'gender' => Post::get('gender'),
                'state' => Post::get('state'),
            ]);
            $user_profile = [
                'user_profile_id' => $user_profile_id,
                'user_id' => $user_id,
                'email' => Post::get('email'),
                'last_name' => Post::get('last_name'),
                'middle_name' => Post::get('middle_name'),
                'first_name' => Post::get('first_name'),
                'full_name' => $full_name,
                'custom_profile' => $custom_profile,
                'created_id' => Auth::getUserId(),
                'updated_id' => Auth::getUserId(),
            ];

            $model_user_profile->create($user_profile);

            Auth::reflesh($user_id);

            DB::commit();

            Html::redirect(Html::url());

        } catch (Throwable $e) {
            fatalLog('想定外の例外が発生しました。', $e);
            $this->showSystemError();
        }
    }

    /**
     * validation
     *
     * @return  array
     */
    private function validation() : array
    {
        $validation = Validation::forge();

        // Login ID
        $validation->addItem('login_id', Post::get('login_id'))
                ->addRule('required', Message::get('required', ['Login ID']))
                ->addRule('maxLength[20]', Message::get('maxLength', ['Login ID', '20']));

        // Password
        $validation->addItem('password', Post::get('password'))
                ->addRule('required', Message::get('required', ['Password']))
                ->addRule('alphanumber', Message::get('alphanumber', ['Password']))
                ->addRule('rangeLength[8][20]', Message::get('lengthRange', ['Password', '8', '20']));

        // Password confirmation
        $validation->addItem('password_confirmation', Post::get('password_confirmation'))
                ->addRule('required', Message::get('required', ['Password confirmation']))
                ->addRule('alphanumber', Message::get('alphanumber', ['Password confirmation']))
                ->addRule('rangeLength[8][20]', Message::get('lengthRange', ['Password confirmation', '8', '20']))
                ->addRule('exact[' . Post::get('password') . ']', Message::get('matchValue', ['Password', 'Password confirmation']));

        // Email address
        $validation->addItem('email', Post::get('email'))
                ->addRule('required', Message::get('required', ['Email address']))
                ->addRule('email', Message::get('invalidFormat', ['Email address']))
                ->addRule('maxLength[100]', Message::get('maxLength', ['Email address', '100']));

        // Last name
        $validation->addItem('last_name', Post::get('last_name'))
                ->addRule('required', Message::get('required', ['Last name']))
                ->addRule('sjis', Message::get('cannotBeUsed', ['Last name']))
                ->addRule('maxLength[10]', Message::get('maxLength', ['Last name', '10']));

        // Middle name
        $validation->addItem('middle_name', Post::get('middle_name'))
                ->addRule('sjis', Message::get('cannotBeUsed', ['Middle name']))
                ->addRule('maxLength[10]', Message::get('maxLength', ['Middle name', '10']));

        // First name
        $validation->addItem('first_name', Post::get('first_name'))
                ->addRule('required', Message::get('required', ['First name']))
                ->addRule('sjis', Message::get('cannotBeUsed', ['First name']))
                ->addRule('maxLength[10]', Message::get('maxLength', ['First name', '10']));

        // Gender
        $validation->addItem('gender', Post::get('gender'))
                ->addRule('required', Message::get('requiredSelect', ['Gender']));

        // State
        $validation->addItem('state', Post::get('state'))
                ->addRule('required', Message::get('requiredSelect', ['State']));

        return $validation->run();
    }

    /**
     * フルネームを生成する。
     *
     * @param  string  $last_name    ラストネーム
     * @param  string  $middle_name  ミドルネーム
     * @param  string  $first_name   ファーストネーム
     * @return  string
     */
    private function creteFullName($last_name, $middle_name, $first_name) : string
    {
        $full_name_arr = [];
        $full_name_arr[] = $last_name;
        if ($middle_name == '') {
            $full_name_arr[] = $middle_name;
        }
        $full_name_arr[] = $first_name;
        return implode(' ', $full_name_arr);
    }

}
