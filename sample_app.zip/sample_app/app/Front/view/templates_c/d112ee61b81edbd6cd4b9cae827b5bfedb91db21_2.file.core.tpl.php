<?php
/* Smarty version 3.1.36, created on 2020-04-20 10:54:30
  from '/var/www/app/Front/view/templates/manual/core.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9d00d63758c6_90014457',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd112ee61b81edbd6cd4b9cae827b5bfedb91db21' => 
    array (
      0 => '/var/www/app/Front/view/templates/manual/core.tpl',
      1 => 1587487082,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./inc/nav.tpl' => 1,
  ),
),false)) {
function content_5e9d00d63758c6_90014457 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_17275004335e9d00d636b431_99624091', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, '../commons/layout/app.tpl');
}
/* {block 'content'} */
class Block_17275004335e9d00d636b431_99624091 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_17275004335e9d00d636b431_99624091',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <?php $_smarty_tpl->_subTemplateRender('file:./inc/nav.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('active'=>'core'), 0, false);
?>

    <h1 class="page-header">
        Core(zcore)
    </h1>

    <article class="pb-5">
        Core(zcore)に含まれているモジュールを簡単に解説しますよ。<br/>
        実際は、ユーザー登録やログイン、ログアウトのソースコードを見るのが早いですよ。
    </article>

    <article class="bg-white shadow mb-5 p-4">
        <h2 class="border-bottom pb-3">Controller</h2>
        <p class="pt-4">
            全てのControllerの基底となるクラスですよ。</br>
            作成するControllerは、全てzcoreのControllerを継承しなければいけないんですよ。</br>
            継承したクラスでは、beforeメソッドおよびafterメソッドを実装することができますよ。</br>
            beforeを実装すると、acitonが呼び出せる前にbeforeに記述した処理が実行されますよ。</br>
            afterを実装すると、acitonが呼び出された後に、afterに記述した処理が実行されますよ。</br>
        </p>
    </article>

    <article class="bg-white shadow mb-5 p-4">
        <h2 class="border-bottom pb-3">Model</h2>
        <p class="pt-4">
            全てのModelの基底となるクラスですよ。</br>
            作成するModelは、全てzcoreのModelを継承しなければいけないんですよ。</br>
            基本的には、テーブルごとにModelクラスを作成すると思いますよ。</br>
            継承したクラスで、SQLテンプレートを格納するディレクトリ名を設定するんですよ。</br>
            継承するだけで、以下6つのメソッドが使えるようになりますよ。</br>
            ただし、SQLを実行するためのメソッドをModelに定義しておけば、SQL発行が全てModelに集約されるのでいいかもしれないですよ。</br>
            <table class="table table-bordered mt-3">
                <thead>
                    <tr>
                       <th>メソッド</th>
                       <th>説明</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                       <td>query</td>
                       <td>SELECT実行。<br/>SQLを文字列で記述して実行する場合に使うんですよ。<br/>二次元配列で返却されますよ。</td>
                    </tr>
                    <tr>
                        <td>queryFirst</td>
                        <td>SELECT実行（最初の1レコードのみ）<br/>SQLを文字列で記述して実行する場合に使うんですよ。<br/>最初の1レコード目の情報が配列で返却されますよ。</td>
                    </tr>
                    <tr>
                        <td>nonQuerye</td>
                        <td>INSERT/UPDATE/DELETE実行<br/>SQLを文字列で記述して実行する場合に使うんですよ。<br/>作用したレコード数が返却されますよ。</td>
                    </tr>
                    <tr>
                        <td>queryByFile</td>
                       <td>SELECT実行<br/>SQLをSmartyテンプレートファイルに記述して実行する場合に使うんですよ。<br/>二次元配列で返却されますよ。</td>
                    </tr>
                    <tr>
                        <td>queryFirstByFile</td>
                        <td>SELECT実行（最初の1レコードのみ）<br/>SQLをSmartyテンプレートファイルに記述して実行する場合に使うんですよ。<br/>最初の1レコード目の情報が配列で返却されますよ。</td>
                    </tr>
                    <tr>
                        <td>queryFirstByFile</td>
                       <td>SELECT実行<br/>SQLをSmartyテンプレートファイルに記述して実行する場合に使うんですよ。<br/>配列で返却されますよ。</td>
                    </tr>
                </tbody>
            </table>
        </p>
    </article>

    <article class="bg-white shadow mb-5 p-4">
        <h2 class="border-bottom pb-3">View</h2>
        <p class="pt-4">
            <p>Viewクラスですよ。</p>
            <p>Viewへの変数の割り当てや、Viewの表示を担いますよ。</p>
        </p>
    </article>

<?php
}
}
/* {/block 'content'} */
}
