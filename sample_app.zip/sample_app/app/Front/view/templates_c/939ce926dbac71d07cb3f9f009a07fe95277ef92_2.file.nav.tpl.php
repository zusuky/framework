<?php
/* Smarty version 3.1.36, created on 2020-04-20 09:55:45
  from '/var/www/app/Front/view/templates/manual/inc/nav.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9cf3113b4dc7_15445306',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '939ce926dbac71d07cb3f9f009a07fe95277ef92' => 
    array (
      0 => '/var/www/app/Front/view/templates/manual/inc/nav.tpl',
      1 => 1587431123,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e9cf3113b4dc7_15445306 (Smarty_Internal_Template $_smarty_tpl) {
?><ul class="nav nav-pills border-bottom mb-5 pb-1">
    <li class="nav-item">
        <a class="nav-link <?php if ((isset($_smarty_tpl->tpl_vars['active']->value)) && $_smarty_tpl->tpl_vars['active']->value == 'index') {?>active<?php }?>" href="<?php echo htmlspecialchars(Html::url('manual'), ENT_QUOTES, 'UTF-8');?>
">概要</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php if ((isset($_smarty_tpl->tpl_vars['active']->value)) && $_smarty_tpl->tpl_vars['active']->value == 'config') {?>active<?php }?>" href="<?php echo htmlspecialchars(Html::url('manual/config'), ENT_QUOTES, 'UTF-8');?>
">Config</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php if ((isset($_smarty_tpl->tpl_vars['active']->value)) && $_smarty_tpl->tpl_vars['active']->value == 'core') {?>active<?php }?>" href="<?php echo htmlspecialchars(Html::url('manual/core'), ENT_QUOTES, 'UTF-8');?>
">Core(zcore)</a>
    </li>
    <li class="nav-item">
        <a class="nav-link <?php if ((isset($_smarty_tpl->tpl_vars['active']->value)) && $_smarty_tpl->tpl_vars['active']->value == 'design') {?>active<?php }?>" href="<?php echo htmlspecialchars(Html::url('manual/design'), ENT_QUOTES, 'UTF-8');?>
">画面デザイン</a>
    </li>
</ul>
<?php }
}
