<?php /* Smarty version 3.1.36, created on 2020-04-20 10:52:34
         compiled from '/var/www/app/Front/resources/messages/ja/message.conf' */ ?>
<?php
/* Smarty version 3.1.36, created on 2020-04-20 10:52:34
  from '/var/www/app/Front/resources/messages/ja/message.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9d00623b91a6_43679337',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd73fb940234039e690b594743c9a0c3790b4cf32' => 
    array (
      0 => '/var/www/app/Front/resources/messages/ja/message.conf',
      1 => 1587608935,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e9d00623b91a6_43679337 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
  ),
  'vars' => 
  array (
    'required' => '%sを入力してください。',
    'requiredSelect' => '%sを選択してください。',
    'alpha' => '%sは半角英字のみで入力してください。',
    'number' => '%sは半角数字のみで入力してください。',
    'alphanumber' => '%sは半角英数字のみで入力してください。',
    'mixed' => '%sは、半角英字と半角数字をそれぞれ1文字以上含む必要があります。',
    'date' => '%sは日付で入力してください。',
    'time' => '%sは時分で入力してください。',
    'invalid' => '%sが無効です。',
    'invalidFormat' => '%sの形式が不正です。',
    'cannotBeUsed' => '%sに使用できない文字を含んでいます。',
    'matchValue' => '%sと%sが一致しません。',
    'zenkaku' => '%sは全角で入力してください。',
    'zenkakuKana' => '%sは全角カナで入力してください。',
    'zenkakuNonSymbol' => '%sは全角（ハイフン以外の記号なし）で入力してください。',
    'zenkakuKanaNonSymbol' => '%sは全角カナ（ハイフン以外の記号なし）で入力してください。',
    'greaterThan' => '%sは%sより大きい値で入力してください。',
    'greaterEqual' => '%sは%s以上で入力してください。',
    'lessThan' => '%sは%sより小さい値で入力してください。',
    'lessEqual' => '%sは%s以下で入力してください。',
    'rangeEqual' => '%sは%s以上、%s以下で入力してください。',
    'lengthMin' => '%sは%s文字以上で入力してください。',
    'lengthMax' => '%sは%s文字以内で入力してください。',
    'lengthRange' => '%sは%s文字以上、%s文字以内で入力してください。',
    'lengthExact' => '%sは%s文字で入力してください。',
    'lengthMinNumber' => '%sは%s桁以上で入力してください。',
    'lengthMaxNumber' => '%sは%s桁以内で入力してください。',
    'lengthRangeNumber' => '%sは%s桁以上、%s桁以内で入力してください。',
    'lengthExactNumber' => '%sは%s桁で入力してください。',
    'errorSessionTimeout' => 'セッションがタイムアウトしました。
お手数ですが操作をはじめからやり直してください。',
    'errorDoubleTransmission' => '二重送信はできません。',
    'errorInvalidOperation' => '不正な画面遷移、または、操作が行われました。
お手数ですが操作をはじめからやり直してください。',
    'errorInvalidUrl' => '無効なURLです。',
    'errorSystem' => '申し訳ありません。ただいまアクセスが集中し、大変混雑しております。
お手数ですが、しばらく時間をおいてから再度アクセスしてください。',
    'errorConnect' => '通信に失敗しました。',
    'errorValidation' => '入力内容に誤りがあります。赤字の項目を修正してください。',
    'errorUnauthorized' => '該当するユーザ情報が見つかりませんでした。入力内容を確認してください。',
  ),
));
}
}
