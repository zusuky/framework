<?php
/* Smarty version 3.1.36, created on 2020-04-20 10:52:34
  from '/var/www/app/Front/view/templates/home/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9d0062327315_45139139',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ddb5114b14143485e4dfdb8b789151877fa785d5' => 
    array (
      0 => '/var/www/app/Front/view/templates/home/index.tpl',
      1 => 1587609219,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e9d0062327315_45139139 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_20800635555e9d00623264d9_70504815', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, '../commons/layout/app.tpl');
}
/* {block 'content'} */
class Block_20800635555e9d00623264d9_70504815 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_20800635555e9d00623264d9_70504815',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <div class="pb-5">
    	<h1 class="pb-5 display-3 text-center">Zusuky</h1>
        <p class="pb-3 text-center">ヤンキーWEB職人のためのフレームワーク。</p>
        <p class="text-center">PHPに支障はありません。楽しくコーディングし、新しい息吹を楽しんでください。</p>
    </div>

<?php
}
}
/* {/block 'content'} */
}
