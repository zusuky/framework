<?php
/* Smarty version 3.1.36, created on 2020-04-20 09:55:45
  from '/var/www/app/Front/view/templates/manual/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9cf311295337_53868000',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '11a6760a832daf5cd6c48b65f5ec269d6ab8488a' => 
    array (
      0 => '/var/www/app/Front/view/templates/manual/index.tpl',
      1 => 1587486457,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./inc/nav.tpl' => 1,
  ),
),false)) {
function content_5e9cf311295337_53868000 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_9673129945e9cf31128b053_55320270', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, '../commons/layout/app.tpl');
}
/* {block 'content'} */
class Block_9673129945e9cf31128b053_55320270 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_9673129945e9cf31128b053_55320270',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <?php $_smarty_tpl->_subTemplateRender('file:./inc/nav.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('active'=>'index'), 0, false);
?>

    <h1 class="page-header">
        概要
    </h1>

    <article class="pb-5">
        Zusukyは超軽量のWEBサイト構築用のフレームワークですよ。<br/>
        Laravelの3倍軽く、3倍早いですよ。（機能は少ないけど。）<br/>
        MVCでの構築が可能ですよ。<br/>
        テンプレートエンジンであるSmartyをラッピングして作っていますよ。<br/>
        あとは、自由度が非常に高いので、自由にしてくださいね。<br/>
        サービス層を設けたり、リポジトリパターンにしたり、使い方はあなた次第ですよ。（他のフレームワーク使う場合もそうですけどね。）<br/>
        初期構築に時間がかかってでも、継続的な機能追加し易さを追求したいのであれば、<a href="https://qiita.com/nrslib/items/a5f902c4defc83bd46b8" target="_blank">クリーンアーキテクチャ</a> を導入して、ものすごくきれいに作るのもいいですよ。お勧めはしませんが。<br/>
        <br/>
        動作条件は、php7.2以上ですよ。<br/>
        未だにnamespaceに対応していませんよ。<br/>
        次のバージョンくらいでnamespaceそろそろ使いますか？（規模が小さな開発であればいらないですけどね。namespaceあると面倒くさいし。）
    </article>

    <article class="bg-white shadow mb-5 p-4">
        <h2 class="border-bottom pb-3">使用ライブラリ</h2>
        <article class="pt-4">
            <p class="mb-3">Zusukyでは、以下のライブラリを使用していますよ。</p>
            <p>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                           <th>ライブラリ</th>
                           <th>バージョン</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>smarty</td>
                            <td>3.1.34</td>
                        </tr>
                        <tr>
                           <td>log4php</td>
                           <td>2.3.0</td>
                        </tr>
                        <tr>
                            <td>phpmailer</td>
                            <td>6.1.5</td>
                        </tr>
                        <tr>
                            <td>uuid</td>
                            <td>4.0.1</td>
                        </tr>
                        <tr>
                            <td>bootstrap4</td>
                            <td>4.4.1</td>
                        </tr>
                    </tbody>
                </table>
            </p>
        </article>
    </article>

    <article class="bg-white shadow mb-5 p-4">
        <h2 class="border-bottom pb-3">ルーティングとMVC</h2>
        <p class="pt-4">
            リクエストURIからControllerとActionを割り出すんですよ。<br/>
            <p class="bg-light my-3 p-3">{Application url} / {Controller name} / {Action name} /</p>
            Application urlが https://framework.zusuky.com/ である場合、<br/>
            例えば、https://framework.zusuky.com/user/register/ というURIでアクセスがあると、<br/>
            以下のController、Actionに処理が割り当てられますよ。<br/>
            <ul class="disc my-2">
                <li>Controller：Controller_user</li>
                <li>Action：action_register</li>
            </ul>
            <p class="text-danger">※該当Controller、Actionが存在しない場合は、404 Not foundになりますよ。</p>
        </p>
        <p class="pt-4">
            Modelはあまり頑張ってないですよ。<br/>
            ORMとか作ってないです。SQL書きましょう。<br/>
            SQLの記述方法には2通ありますよ。
            <ol class="my-2">
                <li>SQLを文字列で記述する。</li>
                <li>SQLをSmartyテンプレートファイルに記述する。</li>
            </ol>
        </p>
        <p class="pt-4">
            ViewはSmartyそのままですよ。<br/>
            素のSmartyをラッピングして、Controllerから少しだけ扱いやすくしている程度ですよ。<br/>
            Smartyの使い方は、本家にお任せしますよ。<br/>
            <a href="https://www.smarty.net/docs/ja/" target="_blank">https://www.smarty.net/docs/ja/</a>
        </p>
    </article>

    <article class="bg-white shadow mb-5 p-4">
        <h2 class="border-bottom pb-3">ディレクトリ構成</h2>
        <p class="pt-4">
            デフォルトは、以下のようなディレクトリ構成になっていますよ。</br>
            別途Service層を設けたりするなど、自由にしていいんですよ。
<pre class="bg-light mt-2 p-3">
app ・・・ アップリケーションディレクトリですよ。この下に、Controller,Model,Viewを作っていくんですよ。
    - Admin ・・・ 管理画面用のappディレクトリですよ。Zusukyでは、デフォルトで管理画面とfront画面を分けて作れるようになってますよ。
        - Controller ・・・ Controller用のディレクトリですよ。
        - Model ・・・ Model用のディレクトリですよ。
            - sql   ・・・ （smarty）SQLテンプレート用のディレクトリですよ。
            - sql_c ・・・ （smarty）SQLテンプレートコンパイル用のディレクトリですよ。
        - View ・・・ View用のディレクトリですよ。
            - cache       ・・・ （smarty）キャッシュ用のディレクトリですよ。
            - configs     ・・・ （smarty）コンフィグファイル（メッセージファイル）用のディレクトリですよ。
            - templates   ・・・ （smarty）viewテンプレート用のディレクトリですよ。
            - templates_c ・・・ （smarty）viewテンプレートコンパイルファイルのディレクトリですよ。
    - Front ・・・ front画面用のappディレクトリですよ。Zusukyでは、デフォルトで管理画面とfront画面を分けて作れるようになってますよ。
        - Controller ・・・ Controller用のディレクトリですよ。
        - Model ・・・ Model用のディレクトリですよ。
            - sql   ・・・ （smarty）sqlテンプレート用のディレクトリですよ。
            - sql_c ・・・ （smarty）sqlテンプレートコンパイル用のディレクトリですよ。
        - View ・・・ View用のディレクトリですよ。
            - cache       ・・・ （smarty）キャッシュ用のディレクトリですよ。
            - configs     ・・・ （smarty）コンフィグファイル（メッセージファイル）用のディレクトリですよ。
            - templates   ・・・ （smarty）viewテンプレート用のディレクトリですよ。
            - templates_c ・・・ （smarty）viewテンプレートコンパイルファイルのディレクトリですよ。

config ・・・ configファイルを置くディレクトリですよ。
    - admin.config.php   ・・・ 管理画面用のconfigですよ。
    - front.config.php   ・・・ front画面用のconfigですよ。
    - log4php.properties ・・・ log4phpの定義ファイルですよ。

zcore   ・・・ Zusukyのcoreモジュールが置かれていますよ。ソースコード量は少ないので、読んでみるといいですよ。

public ・・・ 公開ディレクトリですよ。このpublicディレクトリをDocument rootに指定するんですよ。
    - assets ・・・assetsディレクトリですよ。cssやimgやjsを置くんですよ。
        - admin ・・・ 管理画面用のassetsディレクトリですよ。
            - css  ・・・ cssファイル用のディレクトリですよ。
            - img  ・・・ imgファイル用のディレクトリですよ。
            - js   ・・・ jsファイル用のディレクトリですよ。
            - scss ・・・ sassファイル用のディレクトリですよ。スタイルはsassで管理することをお勧めしますよ。
        - front ・・・ front画面用のassetsディレクトリですよ。
            - css  ・・・ cssファイル用のディレクトリですよ。
            - img  ・・・ imgファイル用のディレクトリですよ。
            - js   ・・・ jsファイル用のディレクトリですよ。
            - scss ・・・ sassファイル用のディレクトリですよ。スタイルはsassで管理することをお勧めしますよ。
    - .htaccess ・・・ apacheで動かすときは必要っですよ。リクエストをindex.phpに集約する記述がされていますよ。
    - health.html ・・・ ロードバランサーのヘルスチェック用htmlですよ。
    - index.php ・・・ index.phpですよ。Zusukyの始まりはここですよ。

vender ・・・ 各種ライブラリ・パッケージですよ。composerで管理するので、venderディレクトリはgitでバージョン管理はしませんよ。
</pre>
        </p>
    </article>

    <article class="bg-white shadow mb-5 p-4">
        <h2 class="border-bottom pb-3">公開ディレクトリ（public）配下のindex.php</h2>
        <p class="pt-4">
            やっているのは以下だけですよ。
<pre class="bg-light mt-3 p-3">
// ライブラリ読み込み
require_once dirname (__DIR__) . '/vendor/autoload.php';

// Zusuky読み込み
require_once dirname (__DIR__) . '/zcore/Zusuky.php';

// Zusukyに魂を注入する
Zusuky::injectSoul();
</pre>
        </article>
    </article>

<?php
}
}
/* {/block 'content'} */
}
