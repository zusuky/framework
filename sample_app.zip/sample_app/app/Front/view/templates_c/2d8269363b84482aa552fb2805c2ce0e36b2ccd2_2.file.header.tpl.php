<?php
/* Smarty version 3.1.36, created on 2020-04-20 10:52:34
  from '/var/www/app/Front/view/templates/commons/layout/header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9d0062439107_71594293',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2d8269363b84482aa552fb2805c2ce0e36b2ccd2' => 
    array (
      0 => '/var/www/app/Front/view/templates/commons/layout/header.tpl',
      1 => 1587609451,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e9d0062439107_71594293 (Smarty_Internal_Template $_smarty_tpl) {
?><header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow">
        <div class="container">
            <a class="navbar-brand" href="<?php echo htmlspecialchars(Html::url(), ENT_QUOTES, 'UTF-8');?>
">
                <img src="<?php echo htmlspecialchars(Html::img('logo.png'), ENT_QUOTES, 'UTF-8');?>
"/> Zusuky Framework - front
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#glovalNavTop" aria-controls="glovalNavTop" aria-expanded="false" aria-label="ナビゲーションの切替">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="glovalNavTop">
                <ul class="navbar-nav">
                    <?php if (Config::get('env') == 'local') {?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo htmlspecialchars(Html::url('manual'), ENT_QUOTES, 'UTF-8');?>
">
                                <i class="fas fa-question-circle"></i> Zusukyマニュアル
                            </a>
                        </li>
                    <?php }?>
                    <?php if (Auth::isLoggedin()) {?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo htmlspecialchars(Html::url('auth/logout'), ENT_QUOTES, 'UTF-8');?>
">
                                <i class="fas fa-sign-in-alt"></i> ログアウト
                            </a>
                        </li>
                    <?php } else { ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo htmlspecialchars(Html::url('user/create'), ENT_QUOTES, 'UTF-8');?>
">
                                <i class="fas fa-user-plus"></i> ユーザー登録
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo htmlspecialchars(Html::url('auth'), ENT_QUOTES, 'UTF-8');?>
">
                                <i class="fas fa-sign-in-alt"></i> ログイン
                            </a>
                        </li>
                    <?php }?>
                </ul>
                <ul class="navbar-nav ml-auto">
                    <?php if (Auth::isLoggedin()) {?>
                        <li class="nav-item dropdown">
                            <a href="" class="nav-link dropdown-toggle" role="button" data-toggle="dropdown" id="navbarDropdownMenuLink" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-user"></i>
                                ようこそ
                                <?php echo htmlspecialchars(Auth::getFullName(), ENT_QUOTES, 'UTF-8');?>

                                さん <span class="caret"></span>
                            </a>
                            <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                <a class="dropdown-item" href="<?php echo htmlspecialchars(Html::url('auth/logout'), ENT_QUOTES, 'UTF-8');?>
">
                                    <i class="fas fa-sign-out-alt"></i> ログアウト
                                </a>
                            </div>
                        </li>
                    <?php } else { ?>
                        <li class="nav-item white">
                            ようこそ ゲスト さん
                        </li>
                    <?php }?>
                </ul>
            </div>
        </div>
    </nav>
</header>
<?php }
}
