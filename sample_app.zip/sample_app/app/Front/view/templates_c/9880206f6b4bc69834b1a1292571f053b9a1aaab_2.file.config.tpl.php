<?php
/* Smarty version 3.1.36, created on 2020-04-20 10:02:13
  from '/var/www/app/Front/view/templates/manual/config.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9cf4952c55e9_72821868',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9880206f6b4bc69834b1a1292571f053b9a1aaab' => 
    array (
      0 => '/var/www/app/Front/view/templates/manual/config.tpl',
      1 => 1587485893,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./inc/nav.tpl' => 1,
  ),
),false)) {
function content_5e9cf4952c55e9_72821868 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_3338415835e9cf4952be3f6_20530482', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, '../commons/layout/app.tpl');
}
/* {block 'content'} */
class Block_3338415835e9cf4952be3f6_20530482 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_3338415835e9cf4952be3f6_20530482',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <?php $_smarty_tpl->_subTemplateRender('file:./inc/nav.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('active'=>'config'), 0, false);
?>

    <h1 class="page-header">
        Config
    </h1>

    <article class="pb-5">
        Configに設定する内容を簡単に解説しますよ。
    </article>

    <article class="bg-white shadow mb-5 p-4">
        <p>
            管理画面用、front画面用それぞれのconfigを定義しますよ。<br/>
            <ul class="disc">
                <li>config.admin.php ・・・ 管理画面用のconfigですよ。</li>
                <li>config.front.php ・・・ front画面用のconfigですよ。</li>
            </ul>
        </p>
        <p class="mt-4">
            以下のようなものを定義しますよ。
            <ul class="disc">
                <li>環境文字列</li>
                <li>appディレクトリ</li>
                <li>HTML（URL）</li>
                <li>HOME画面URI</li>
                <li>データソース</li>
                <li>メッセージファイル</li>
                <li>log4php</li>
                <li>セッション</li>
                <li>暗号化</li>
                <li>ベーシック認証情</li>
            </ul>
        </p>
        <p class="mt-4">
            具体例は以下ですよ。</p>
<pre class="bg-light mt-3 p-3">
    // 環境文字列（local|testing|staging|production）
    'env' => 'local',

    // appディレクトリ
    'app_dir' => [
        // appのrootとなるディレクトリ
        'root'             => '/var/www/app/front/',

        // controllerのディレクトリ
        'controller'       => '/var/www/app/front/controller/',

        // modelのディレクトリ
        'model'            => '/var/www/app/front/model/',
        'model_sql'        => '/var/www/app/front/model/sql/',
        'model_sql_c'      => '/var/www/app/front/model/sql_c/',

        // viewのディレクトリ
        'view'             => '/var/www/app/front/view/',
        'view_cache'       => '/var/www/app/front/view/cache/',
        'view_configs'     => '/var/www/app/front/view/configs/',
        'view_templates'   => '/var/www/app/front/view/templates/',
        'view_templates_c' => '/var/www/app/front/view/templates_c/',
    ],

    // HTML
    'html' => [
        // アプリケーションのベースURL
        'url'  => 'http://localhost' . (Lang::getCurrent() === Lang::getDefault() ? '' : '/' . Lang::getCurrent()) . '/',

        // cssのベースURL
        'css'  => 'http://localhost/assets/front/css/',

        // jsのベースURL
        'js'   => 'http://localhost/assets/front/js/',

        // imgのベースURL
        'img'  => 'http://localhost/assets/front/img/',
    ],

    // HOME画面URI（リクエストにURIが無い場合は、このHOME画面のURIが指定されたものとして動作する）
    'uri_home' => '/home/index/'

    // データソース
    'datasource' => [
        // 接続対象のDBMS（mysql|oracle)
        'connection' => 'mysql',

        // mysql（PDO）接続定義
        'mysql' => [
            'host'     => 'mysql',
            'port'     => '3306',
            'database' => 'mydb',
            'user'     => 'root',
            'pass'     => 'pass',
        ],

        // oracle（OCI8）接続定義
        'oracle' => [
            'sid'  => '',
            'user' => '',
            'pass' => '',
            'env'  => [
                'nls_lang'        => '',
                'oracle_home'     => '',
                'ld_library_path' => '',
            ],
        ],
    ],

    // メッセージファイル
    'message_conf' => sprintf('message_%s.conf', Lang::getCurrent()),

    // log4php
    'log4php' => [
        // log4phpプロパティファイルのパス
        'properties' => __DIR__ . '/log4php.properties',

        // logger
        'logger' => 'frontLogger',
    ],

    // セッション
    'session' => [
        'save_handler'   => 'files',
        'save_path'      => '/tmp',
        'save_name'      => 'zusukyfrontsid',
        'gc_maxlifetime' => 3600,
        'gc_probability' => 1,
        'gc_divisor'     => 1,
        'cookie_secure'  => 0,
    ],

    // 暗号化
    'crypt' => [
        'key'    => 'xxxxxxxxxxxxxxxx',
        'method' => 'AES-256-CBC',
    ],

    // ベーシック認証
    'basic_auth' => [
        'user' => '',
        'pass' => '',
    ],
</pre>
        </p>
    </article>

<?php
}
}
/* {/block 'content'} */
}
