<?php
/* Smarty version 3.1.36, created on 2020-04-20 09:58:21
  from '/var/www/app/Front/view/templates/auth/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9cf3ad1689a4_18014682',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '46e8bf747d7daacf579439de61c973ea65ef9789' => 
    array (
      0 => '/var/www/app/Front/view/templates/auth/index.tpl',
      1 => 1587534673,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../commons/form_components/text.tpl' => 1,
    'file:../commons/form_components/password.tpl' => 1,
  ),
),false)) {
function content_5e9cf3ad1689a4_18014682 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
$_smarty_tpl->_assignInScope('is_small_content', "1");?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_8957023735e9cf3ad14fa27_60685002', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, '../commons/layout/app.tpl');
}
/* {block 'content'} */
class Block_8957023735e9cf3ad14fa27_60685002 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_8957023735e9cf3ad14fa27_60685002',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <?php echo '<script'; ?>
>
        $(function(){
            var init = function(){
                if ($('form .error-message').length) {
                    var position = $('form .error-message').first().offset().top -200;
                    
                    $('html, body').animate({scrollTop: position}, 800);
                    
                    $('.toast-error .toast-body').html('<?php echo htmlspecialchars($_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'errorValidation'), ENT_QUOTES, 'UTF-8');?>
');
                    
                    $('.toast-error').toast({ delay: 3000 });
                    
                    $('.toast-error').toast('show');
                }
            };
            var auth = function(){
                $('#form-main').submit();
            };
            init();
            $("#btn-auth").on('click', function(){
                auth();
            });
        });
    <?php echo '</script'; ?>
>

    <h1 class="page-header">
        ログイン
    </h1>

    <div class="bg-white shadow p-4">
        <form method="post" action="<?php echo htmlspecialchars(Html::url('auth/login'), ENT_QUOTES, 'UTF-8');?>
" id="form-main">
            <?php $_smarty_tpl->_subTemplateRender('file:../commons/form_components/text.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('label'=>'Login ID','name'=>"login_id",'value'=>$_smarty_tpl->tpl_vars['login_id']->value,'placeholder'=>"Enter Login ID"), 0, false);
?>
            <?php $_smarty_tpl->_subTemplateRender('file:../commons/form_components/password.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('label'=>'Password','name'=>"password",'value'=>$_smarty_tpl->tpl_vars['password']->value,'placeholder'=>"Enter Password"), 0, false);
?>
            <button type="button" class="btn btn-primary" id="btn-auth">ログイン</button>
        </form>
    </div>

<?php
}
}
/* {/block 'content'} */
}
