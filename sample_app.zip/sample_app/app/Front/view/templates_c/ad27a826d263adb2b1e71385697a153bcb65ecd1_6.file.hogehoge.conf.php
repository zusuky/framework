<?php /* Smarty version 3.1.36, created on 2020-04-20 09:56:58
         compiled from '/var/www/app/Front/resources/messages/ja/hogehoge.conf' */ ?>
<?php
/* Smarty version 3.1.36, created on 2020-04-20 09:56:58
  from '/var/www/app/Front/resources/messages/ja/hogehoge.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9cf35a2bb9a5_12569199',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ad27a826d263adb2b1e71385697a153bcb65ecd1' => 
    array (
      0 => '/var/www/app/Front/resources/messages/ja/hogehoge.conf',
      1 => 1587606402,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e9cf35a2bb9a5_12569199 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
  ),
  'vars' => 
  array (
    'dddd' => 'dfdfdf',
  ),
));
}
}
