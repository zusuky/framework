<?php
/* Smarty version 3.1.36, created on 2020-04-20 10:54:30
  from '/var/www/app/Front/view/templates/manual/design.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9d00d6e41219_20025468',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'caa60f13fcf4862f8c4e4203b36d37fd7ad409e0' => 
    array (
      0 => '/var/www/app/Front/view/templates/manual/design.tpl',
      1 => 1587512511,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./inc/nav.tpl' => 1,
  ),
),false)) {
function content_5e9d00d6e41219_20025468 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_3374589775e9d00d6e39f91_12481994', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, '../commons/layout/app.tpl');
}
/* {block 'content'} */
class Block_3374589775e9d00d6e39f91_12481994 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_3374589775e9d00d6e39f91_12481994',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <?php $_smarty_tpl->_subTemplateRender('file:./inc/nav.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('active'=>'design'), 0, false);
?>

    <h1 class="page-header">
        画面デザイン
    </h1>

    <article class="pb-5">
        <p>デザインにはBoostrap4を使用するのが良いでしょう。</p>
        <p class="pb-4"><a href="https://getbootstrap.jp/docs/4.2/getting-started/introduction/" target="_blank">https://getbootstrap.jp/docs/4.2/getting-started/introduction/</a></p>
        <p>以下、基本的なもの、よく使うものへのリンク集ですよ。</p>
    </article>

    <div class="shadow mb-5 p-4">
        <h2 class="border-bottom pb-3">Layout</h2>
        <article class="pt-4">
            <h3><i class="fas fa-caret-down"></i> Layout</h3>
            <a href="https://getbootstrap.jp/docs/4.2/layout/overview/" target="_blank">https://getbootstrap.jp/docs/4.2/layout/overview/</a>
        </article>
        <article class="pt-4">
            <h3><i class="fas fa-caret-down"></i> Grid</h3>
            <a href="https://getbootstrap.jp/docs/4.2/layout/grid/" target="_blank">https://getbootstrap.jp/docs/4.2/layout/grid/</a>
        </article>
        <article class="pt-4">
            <h3><i class="fas fa-caret-down"></i> Utilities for layout</h3>
            <a href="https://getbootstrap.jp/docs/4.2/layout/utilities-for-layout/" target="_blank">https://getbootstrap.jp/docs/4.2/layout/utilities-for-layout/</a>
        </article>
    </div>

    <div class="shadow mb-5 p-4">
        <h2 class="border-bottom pb-3">Components</h2>
        <article class="pt-4">
            <h3><i class="fas fa-caret-down"></i> Alerts</h3>
            <a href="https://getbootstrap.jp/docs/4.2/components/alerts/" target="_blank">https://getbootstrap.jp/docs/4.2/components/alerts/</a>
        </article>
         <article class="pt-4">
            <h3><i class="fas fa-caret-down"></i> Badges</h3>
            <a href="https://getbootstrap.jp/docs/4.2/components/badge/" target="_blank">https://getbootstrap.jp/docs/4.2/components/badge/</a>
        </article>
        <article class="pt-4">
            <h3><i class="fas fa-caret-down"></i> Breadcrumb</h3>
            <a href="https://getbootstrap.jp/docs/4.2/components/breadcrumb/" target="_blank">https://getbootstrap.jp/docs/4.2/components/breadcrumb/</a>
        </article>
         <article class="pt-4">
            <h3><i class="fas fa-caret-down"></i> Buttons</h3>
            <a href="https://getbootstrap.jp/docs/4.2/components/buttons/" target="_blank">https://getbootstrap.jp/docs/4.2/components/buttons/</a>
        </article>
         <article class="pt-4">
            <h3><i class="fas fa-caret-down"></i> Cards</h3>
            <a href="https://getbootstrap.jp/docs/4.2/components/card/" target="_blank">https://getbootstrap.jp/docs/4.2/components/card/</a>
        </article>
         <article class="pt-4">
            <h3><i class="fas fa-caret-down"></i> Dropdowns</h3>
            <a href="https://getbootstrap.jp/docs/4.2/components/dropdowns/" target="_blank">https://getbootstrap.jp/docs/4.2/components/dropdowns/</a>
        </article>
         <article class="pt-4">
            <h3><i class="fas fa-caret-down"></i> Forms</h3>
            <a href="https://getbootstrap.jp/docs/4.2/components/forms/" target="_blank">https://getbootstrap.jp/docs/4.2/components/forms/</a>
            <br/><br/>
            <form action="">
                <div class="form-group">
                    <label for="exampleInputEmail1">Email address</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
                    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Password</label>
                    <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
                </div>
                <div class="form-group">
                    <label for="exampleFormControlSelect1">Example select</label>
                    <select class="form-control" id="exampleFormControlSelect1">
                      <option>1</option>
                      <option>2</option>
                      <option>3</option>
                      <option>4</option>
                      <option>5</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Example check</label>
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" id="exampleCheck1">
                        <label class="form-check-label" for="exampleCheck1">Check me out</label>
                    </div>
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" id="exampleCheck2">
                        <label class="form-check-label" for="exampleCheck2">Check me out</label>
                    </div>
                </div>
                <div class="form-group">
                    <label>Example radio</label>
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                      <label class="form-check-label" for="exampleRadios1">
                          Default radio
                      </label>
                    </div>
                    <div class="form-check">
                      <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios2" value="option2">
                      <label class="form-check-label" for="exampleRadios2">
                          Second default radio
                      </label>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </article>
         <article class="pt-4">
            <h3><i class="fas fa-caret-down"></i> Navs</h3>
            <a href="https://getbootstrap.jp/docs/4.2/components/navs/" target="_blank">https://getbootstrap.jp/docs/4.2/components/navs/</a>
        </article>
         <article class="pt-4">
            <h3><i class="fas fa-caret-down"></i> Navbar</h3>
            <a href="https://getbootstrap.jp/docs/4.2/components/navbar/" target="_blank">https://getbootstrap.jp/docs/4.2/components/navbar/</a>
        </article>
        <article class="pt-4">
            <h3><i class="fas fa-caret-down"></i> Pagination</h3>
            <a href="https://getbootstrap.jp/docs/4.2/components/pagination/" target="_blank">https://getbootstrap.jp/docs/4.2/components/pagination/</a>
        </article>
    </div>

    <div class="shadow mb-5 p-4">
        <h2 class="border-bottom pb-3">Content</h2>
        <article class="pt-4">
            <h3><i class="fas fa-caret-down"></i> Images</h3>
            <a href="https://getbootstrap.jp/docs/4.2/content/images/" target="_blank">https://getbootstrap.jp/docs/4.2/content/images/</a>
        </article>
         <article class="pt-4">
            <h3><i class="fas fa-caret-down"></i> Tables</h3>
            <a href="https://getbootstrap.jp/docs/4.2/content/tables/" target="_blank">https://getbootstrap.jp/docs/4.2/content/tables/</a>
        </article>
    </div>

    <div class="shadow mb-5 p-4">
        <h2 class="border-bottom pb-3">Utilities</h2>
        <article class="pt-4">
            <h3><i class="fas fa-caret-down"></i> Borders</h3>
            <a href="https://getbootstrap.jp/docs/4.2/utilities/borders/" target="_blank">https://getbootstrap.jp/docs/4.2/utilities/borders/</a>
        </article>
         <article class="pt-4">
            <h3><i class="fas fa-caret-down"></i> Colors</h3>
            <a href="https://getbootstrap.jp/docs/4.2/utilities/colors/" target="_blank">https://getbootstrap.jp/docs/4.2/utilities/colors/</a>
        </article>
        <article class="pt-4">
            <h3><i class="fas fa-caret-down"></i> Display property</h3>
            <a href="https://getbootstrap.jp/docs/4.2/utilities/display/" target="_blank">https://getbootstrap.jp/docs/4.2/utilities/display/</a>
        </article>
        <article class="pt-4">
            <h3><i class="fas fa-caret-down"></i> Flex</h3>
            <a href="https://getbootstrap.jp/docs/4.2/utilities/flex/" target="_blank">https://getbootstrap.jp/docs/4.2/utilities/flex/</a>
        </article>
         <article class="pt-4">
            <h3><i class="fas fa-caret-down"></i> Shadows</h3>
            <a href="https://getbootstrap.jp/docs/4.2/utilities/shadows/" target="_blank">https://getbootstrap.jp/docs/4.2/utilities/shadows/</a>
        </article>
         <article class="pt-4">
            <h3><i class="fas fa-caret-down"></i> Sizing</h3>
            <a href="https://getbootstrap.jp/docs/4.2/utilities/sizing/" target="_blank">https://getbootstrap.jp/docs/4.2/utilities/sizing/</a>
        </article>
         <article class="pt-4">
            <h3><i class="fas fa-caret-down"></i> Spacing</h3>
            <a href="https://getbootstrap.jp/docs/4.2/utilities/spacing/" target="_blank">https://getbootstrap.jp/docs/4.2/utilities/spacing/</a>
        </article>
         <article class="pt-4">
            <h3><i class="fas fa-caret-down"></i> Text</h3>
            <a href="https://getbootstrap.jp/docs/4.2/utilities/text/" target="_blank">https://getbootstrap.jp/docs/4.2/utilities/text/</a>
        </article>
        <article class="pt-4">
            <h3><i class="fas fa-caret-down"></i> Vertical alignment</h3>
            <a href="https://getbootstrap.jp/docs/4.2/utilities/vertical-align/" target="_blank">https://getbootstrap.jp/docs/4.2/utilities/vertical-align/</a>
        </article>
    </div>

<?php
}
}
/* {/block 'content'} */
}
