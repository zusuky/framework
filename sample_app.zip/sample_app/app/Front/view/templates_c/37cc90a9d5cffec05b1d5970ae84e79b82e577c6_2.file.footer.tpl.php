<?php
/* Smarty version 3.1.36, created on 2020-04-20 09:40:13
  from '/var/www/app/Front/view/templates/commons/layout/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9cef6d599e85_35400802',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '37cc90a9d5cffec05b1d5970ae84e79b82e577c6' => 
    array (
      0 => '/var/www/app/Front/view/templates/commons/layout/footer.tpl',
      1 => 1587377721,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e9cef6d599e85_35400802 (Smarty_Internal_Template $_smarty_tpl) {
?><footer class="pb-5">
    <div class="container">
        <ul class="nav d-flex justify-content-center flex-wrap mb-2">
            <li class="nav-item">
                <a class="nav-link" href="https://www.rococo.co.jp/" target="_blank">株式会社ロココ</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="http://13.113.74.195/sse/Zusuky" target="_blank">Zusuky</a>
            </li>
        </ul>
        <div class="d-flex justify-content-center">
            Copyright © ROCOCO Co., Ltd. All rights reserved.
        </div>
    </div>
</footer>
<?php }
}
