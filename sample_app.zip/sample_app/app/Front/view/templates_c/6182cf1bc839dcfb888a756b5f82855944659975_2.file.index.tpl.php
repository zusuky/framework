<?php
/* Smarty version 3.1.36, created on 2020-04-20 10:24:41
  from '/var/www/app/Front/view/templates/user/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9cf9d9d0ba75_53108790',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6182cf1bc839dcfb888a756b5f82855944659975' => 
    array (
      0 => '/var/www/app/Front/view/templates/user/index.tpl',
      1 => 1587607959,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../commons/form_components/text.tpl' => 4,
    'file:../commons/form_components/password.tpl' => 2,
    'file:../commons/form_components/email.tpl' => 1,
    'file:../commons/form_components/radio.tpl' => 1,
    'file:../commons/form_components/select.tpl' => 1,
  ),
),false)) {
function content_5e9cf9d9d0ba75_53108790 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_16559612575e9cf9d9cd4f51_76649008', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, '../commons/layout/app.tpl');
}
/* {block 'content'} */
class Block_16559612575e9cf9d9cd4f51_76649008 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_16559612575e9cf9d9cd4f51_76649008',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <?php echo '<script'; ?>
>
        $(function(){
            var init = function(){
                if ($('#error-conflict').length) {
                    $('.toast-error .toast-body').text($('#error-conflict').text());
                    
                    $('.toast-error').toast({ delay: 3000 });
                    
                    $('.toast-error').toast('show');
                }
                if ($('form .error-message').length) {
                    var position = $('form .error-message').first().offset().top -200;
                    
                    $('html, body').animate({scrollTop: position}, 800);
                    
                    $('.toast-error .toast-body').html('<?php echo htmlspecialchars($_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'errorValidation'), ENT_QUOTES, 'UTF-8');?>
');
                    
                    $('.toast-error').toast({ delay: 3000 });
                    
                    $('.toast-error').toast('show');
                }
            };
            var register = function(){
                $('#form-main').submit();
            };
            init();
            $("#btn-register").on('click', function(){
                register();
            });
        });
    <?php echo '</script'; ?>
>

    <h1 class="page-header">
        ユーザー登録
    </h1>

    <?php if ((isset($_smarty_tpl->tpl_vars['errors']->value['conflict']))) {?>
        <div class="d-none" id="error-conflict"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['errors']->value['conflict'], ENT_QUOTES, 'UTF-8');?>
</div>
    <?php }?>

    <div class="bg-white shadow p-4">
        <form method="post" action="<?php echo htmlspecialchars(Html::url('user/create_save'), ENT_QUOTES, 'UTF-8');?>
" id="form-main">
            <?php $_smarty_tpl->_subTemplateRender('file:../commons/form_components/text.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('label'=>'Login ID','name'=>"login_id",'value'=>$_smarty_tpl->tpl_vars['login_id']->value,'maxlength'=>"20",'placeholder'=>"Enter Login ID",'help_below'=>"*Only single-byte alphanumeric characters"), 0, false);
?>
            <?php $_smarty_tpl->_subTemplateRender('file:../commons/form_components/password.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('label'=>'Password','name'=>"password",'value'=>$_smarty_tpl->tpl_vars['password']->value,'maxlength'=>"20",'placeholder'=>"Enter Password"), 0, false);
?>
            <?php $_smarty_tpl->_subTemplateRender('file:../commons/form_components/password.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('label'=>'Password confirmation','name'=>"password_confirmation",'value'=>$_smarty_tpl->tpl_vars['password_confirmation']->value,'maxlength'=>"20",'placeholder'=>"Enter Password confirmation"), 0, true);
?>
            <?php $_smarty_tpl->_subTemplateRender('file:../commons/form_components/email.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('label'=>'Email address','name'=>"email",'value'=>$_smarty_tpl->tpl_vars['email']->value,'maxlength'=>"100",'placeholder'=>"Enter Email address"), 0, false);
?>
            <?php $_smarty_tpl->_subTemplateRender('file:../commons/form_components/text.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('label'=>'Last name','name'=>"last_name",'value'=>$_smarty_tpl->tpl_vars['last_name']->value,'maxlength'=>"10",'placeholder'=>"Enter Last name"), 0, true);
?>
            <?php $_smarty_tpl->_subTemplateRender('file:../commons/form_components/text.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('label'=>'Middle name','name'=>"middle_name",'value'=>$_smarty_tpl->tpl_vars['middle_name']->value,'maxlength'=>"10",'placeholder'=>"Enter Middle name"), 0, true);
?>
            <?php $_smarty_tpl->_subTemplateRender('file:../commons/form_components/text.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('label'=>'First name','name'=>"first_name",'value'=>$_smarty_tpl->tpl_vars['first_name']->value,'maxlength'=>"10",'placeholder'=>"Enter First name"), 0, true);
?>
            <?php $_smarty_tpl->_subTemplateRender('file:../commons/form_components/radio.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('label'=>'Gender','name'=>"gender",'options'=>UserGenderConst::LIST,'checked'=>$_smarty_tpl->tpl_vars['gender']->value,'help_above'=>"*For transsexuals, please select other."), 0, false);
?>
            <?php $_smarty_tpl->_subTemplateRender('file:../commons/form_components/select.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('label'=>'State','name'=>"state",'add_empty'=>true,'options'=>UserProfileStateConst::LIST,'selected'=>$_smarty_tpl->tpl_vars['state']->value), 0, false);
?>
            <button type="button" class="btn btn-primary" id="btn-register">登録</button>
        </form>
    </div>

<?php
}
}
/* {/block 'content'} */
}
