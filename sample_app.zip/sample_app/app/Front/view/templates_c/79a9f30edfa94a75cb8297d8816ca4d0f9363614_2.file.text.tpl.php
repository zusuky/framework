<?php
/* Smarty version 3.1.36, created on 2020-04-20 09:40:13
  from '/var/www/app/Front/view/templates/commons/form_components/text.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9cef6d2de860_44160208',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '79a9f30edfa94a75cb8297d8816ca4d0f9363614' => 
    array (
      0 => '/var/www/app/Front/view/templates/commons/form_components/text.tpl',
      1 => 1587533502,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e9cef6d2de860_44160208 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="form-group">
<?php if ((isset($_smarty_tpl->tpl_vars['label']->value))) {?>
    <label><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['label']->value, ENT_QUOTES, 'UTF-8');?>
</label>
<?php }
if ((isset($_smarty_tpl->tpl_vars['help_above']->value))) {?>
    <div class="form-text text-muted mt-0 mb-1"><?php echo $_smarty_tpl->tpl_vars['help_above']->value;?>
</div>
<?php }?>
    <input type="text" class="form-control" <?php if ((isset($_smarty_tpl->tpl_vars['name']->value))) {?>name="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['name']->value, ENT_QUOTES, 'UTF-8');?>
" <?php }
if ((isset($_smarty_tpl->tpl_vars['id']->value))) {?>id="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['id']->value, ENT_QUOTES, 'UTF-8');?>
" <?php }
if ((isset($_smarty_tpl->tpl_vars['value']->value))) {?>value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['value']->value, ENT_QUOTES, 'UTF-8');?>
" <?php } else { ?>value="" <?php }
if ((isset($_smarty_tpl->tpl_vars['placeholder']->value))) {?>placeholder="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['placeholder']->value, ENT_QUOTES, 'UTF-8');?>
" <?php }
if ((isset($_smarty_tpl->tpl_vars['maxlength']->value))) {?>maxlength="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['maxlength']->value, ENT_QUOTES, 'UTF-8');?>
" <?php }
if ((isset($_smarty_tpl->tpl_vars['readonly']->value))) {?>readonly <?php }
if ((isset($_smarty_tpl->tpl_vars['disabled']->value))) {?>disabled <?php }?>/>
<?php if ((isset($_smarty_tpl->tpl_vars['help_below']->value))) {?>
    <div class="form-text text-muted"><?php echo $_smarty_tpl->tpl_vars['help_below']->value;?>
</div>
<?php }
if ((isset($_smarty_tpl->tpl_vars['name']->value)) && (isset($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->tpl_vars['name']->value]))) {?>
    <div class="my-1 error-message"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->tpl_vars['name']->value], ENT_QUOTES, 'UTF-8');?>
</div>
<?php }?>
</div>
<?php }
}
