<?php
/* Smarty version 3.1.36, created on 2020-04-20 09:40:13
  from '/var/www/app/Front/view/templates/commons/form_components/radio.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9cef6d48c797_44025789',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ea0e9098587d2ce59bc060f23bd02d980ea248e6' => 
    array (
      0 => '/var/www/app/Front/view/templates/commons/form_components/radio.tpl',
      1 => 1587533491,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e9cef6d48c797_44025789 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="form-group">
<?php if ((isset($_smarty_tpl->tpl_vars['label']->value))) {?>
    <label><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['label']->value, ENT_QUOTES, 'UTF-8');?>
</label>
<?php }
if ((isset($_smarty_tpl->tpl_vars['help_above']->value))) {?>
    <div class="form-text text-muted mt-0 mb-1"><?php echo $_smarty_tpl->tpl_vars['help_above']->value;?>
</div>
<?php }
if ((isset($_smarty_tpl->tpl_vars['options']->value)) && !empty($_smarty_tpl->tpl_vars['options']->value)) {?>
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['options']->value, 'val', false, 'key');
$_smarty_tpl->tpl_vars['val']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['val']->value) {
$_smarty_tpl->tpl_vars['val']->do_else = false;
?>
        <div class="form-check">
            <label>
                <input type="radio" class="form-check-input" value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['key']->value, ENT_QUOTES, 'UTF-8');?>
" <?php if ((isset($_smarty_tpl->tpl_vars['name']->value))) {?>name="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['name']->value, ENT_QUOTES, 'UTF-8');?>
" <?php }?> <?php if ((isset($_smarty_tpl->tpl_vars['checked']->value)) && $_smarty_tpl->tpl_vars['checked']->value == $_smarty_tpl->tpl_vars['key']->value) {?>checked<?php }?>/>
                <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['val']->value, ENT_QUOTES, 'UTF-8');?>

            </label>
        </div>
    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
}
if ((isset($_smarty_tpl->tpl_vars['help_below']->value))) {?>
    <div class="form-text text-muted"><?php echo $_smarty_tpl->tpl_vars['help_below']->value;?>
</div>
<?php }
if ((isset($_smarty_tpl->tpl_vars['name']->value)) && (isset($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->tpl_vars['name']->value]))) {?>
    <div class="my-1 error-message"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->tpl_vars['name']->value], ENT_QUOTES, 'UTF-8');?>
</div>
<?php }?>
</div>



<?php }
}
