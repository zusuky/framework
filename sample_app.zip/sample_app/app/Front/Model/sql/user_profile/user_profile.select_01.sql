SELECT *
  FROM user_profile
 WHERE user_id = :user_id
