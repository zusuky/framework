SELECT *
  FROM user
 WHERE user_id = :user_id
