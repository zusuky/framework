UPDATE user
   SET loggedin_at = CURRENT_TIMESTAMP
 WHERE user_id = :user_id
