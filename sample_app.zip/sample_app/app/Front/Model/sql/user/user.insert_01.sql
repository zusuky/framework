INSERT INTO user
(
       user_id
      ,login_id
      ,password
      ,status
      ,created_id
      ,updated_id
)
VALUES
(
       :user_id
      ,:login_id
      ,:password
      ,:status
      ,:created_id
      ,:updated_id
)
