SELECT *
  FROM user
 WHERE login_id = :login_id
