SELECT *
  FROM user u
  JOIN user_profile up
 WHERE 1 = 1
{if isset($login_id)}
   AND u.login_id LIKE CONCAT('%', :login_id, '%')
{/if}
{if isset($status)}
   AND u.status = :status
{/if}
{if isset($email)}
   AND up.email LIKE CONCAT('%', :email, '%')
{/if}
{if isset($full_name)}
   AND up.full_name LIKE CONCAT('%', :full_name, '%')
{/if}
{if isset($order_by)}
 ORDER BY {$order_by}
{else}
 ORDER BY u.created_at DESC
         ,u.user_id ASC
{/if}
{if isset($limit)}
 LIMIT :limit
{/if}
{if isset($offset)}
OFFSET :offset
{/if}
