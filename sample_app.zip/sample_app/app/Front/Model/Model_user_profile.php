<?php

class Model_user_profile extends Model {

	/** @ver  string  SQLファイル格納ディレクトリ名 */
	protected string $sql_dirname = 'user_profile';

	public function create($user_profile) : int
	{
		$sql_params = SQLParameter::forge();
		$sql_params->add('user_profile_id', Arr::get($user_profile, 'user_profile_id'))
				->add('user_id', Arr::get($user_profile, 'user_id'))
				->add('email', Arr::get($user_profile, 'email'))
				->add('last_name', Arr::get($user_profile, 'last_name'))
				->add('middle_name', Arr::get($user_profile, 'middle_name'))
				->add('first_name', Arr::get($user_profile, 'first_name'))
				->add('full_name', Arr::get($user_profile, 'full_name'))
				->add('custom_profile', Arr::get($user_profile, 'custom_profile'))
				->add('created_id', Arr::get($user_profile, 'created_id'))
				->add('updated_id', Arr::get($user_profile, 'updated_id'));

		return $this->nonQueryByFile('user_profile.insert_01.sql', $sql_params);
	}

	public function findByUserId($user_id) : array
	{
		$sql_params = SQLParameter::forge();
		$sql_params->add('user_id', $user_id);

		return $this->queryFirstByFile('user_profile.select_01.sql', $sql_params);
	}

}

