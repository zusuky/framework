<?php

class Model_user extends Model {

	/** @ver  string  SQLファイル格納ディレクトリ名 */
	protected string $sql_dirname = 'user';

	public function create($user) : int
	{
		$sql_params = SQLParameter::forge();
		$sql_params->add('user_id', Arr::get($user, 'user_id'))
				->add('login_id', Arr::get($user, 'login_id'))
				->add('password', Arr::get($user, 'password'))
				->add('status', Arr::get($user, 'status'))
				->add('created_id', Arr::get($user, 'created_id'))
				->add('updated_id', Arr::get($user, 'updated_id'));

		return $this->nonQueryByFile('user.insert_01.sql', $sql_params);
	}

	public function find($user_id) : array
	{
		$sql_params = SQLParameter::forge();
		$sql_params->add('user_id', $user_id);

		return $this->queryFirstByFile('user.select_01.sql', $sql_params);
	}

	public function findByLoginId($login_id) : array
	{
		$sql_params = SQLParameter::forge();
		$sql_params->add('login_id', $login_id);

		return $this->queryFirstByFile('user.select_02.sql', $sql_params);
	}

	public function where($condition) : array
	{
		$sql_params = SQLParameter::forge();
		if (Arr::keyExists($condition, 'login_id')) {
			$sql_params->add('login_id', Arr::get($condition, 'login_id'));
		}
		if (Arr::keyExists($condition, 'status')) {
			$sql_params->add('status', Arr::get($condition, 'status'));
		}
		if (Arr::keyExists($condition, 'email')) {
			$sql_params->add('email', Arr::get($condition, 'email'));
		}
		if (Arr::keyExists($condition, 'full_name')) {
			$sql_params->add('full_name', Arr::get($condition, 'full_name'));
		}
		if (Arr::keyExists($condition, 'order_by')) {
			$sql_params->addAssign('order_by', Arr::get($condition, 'order_by'));
		}
		if (Arr::keyExists($condition, 'limit')) {
			$sql_params->add('limit', Arr::get($condition, 'limit'));
		}
		if (Arr::keyExists($condition, 'offset')) {
			$sql_params->add('offset', Arr::get($condition, 'offset'));
		}

		return $this->queryByFile('user.select_03.sql', $sql_params);
	}

	public function updateLoggedInAt($user_id) : int
	{
		$sql_params = SQLParameter::forge();
		$sql_params->add('user_id', $user_id);

		return $this->nonQueryByFile('user.update_01.sql', $sql_params);
	}

}

