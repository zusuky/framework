<?php
/* Smarty version 3.1.36, created on 2020-04-19 20:46:22
  from '/var/www/app/Front/Model/sql/user/user.select_01.sql' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9c3a0e2e17a9_26808334',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1fd207c8c1209a7771b9564596157c100d611813' => 
    array (
      0 => '/var/www/app/Front/Model/sql/user/user.select_01.sql',
      1 => 1587518709,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e9c3a0e2e17a9_26808334 (Smarty_Internal_Template $_smarty_tpl) {
?>SELECT *
  FROM user
 WHERE user_id = :user_id
<?php }
}
