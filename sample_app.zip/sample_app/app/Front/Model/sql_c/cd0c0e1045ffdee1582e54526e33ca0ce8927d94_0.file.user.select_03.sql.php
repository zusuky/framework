<?php
/* Smarty version 3.1.36, created on 2020-04-19 20:46:21
  from '/var/www/app/Front/Model/sql/user/user.select_03.sql' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9c3a0dda6644_11453350',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cd0c0e1045ffdee1582e54526e33ca0ce8927d94' => 
    array (
      0 => '/var/www/app/Front/Model/sql/user/user.select_03.sql',
      1 => 1587527693,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e9c3a0dda6644_11453350 (Smarty_Internal_Template $_smarty_tpl) {
?>SELECT *
  FROM user u
  JOIN user_profile up
 WHERE 1 = 1
<?php if ((isset($_smarty_tpl->tpl_vars['login_id']->value))) {?>
   AND u.login_id LIKE CONCAT('%', :login_id, '%')
<?php }
if ((isset($_smarty_tpl->tpl_vars['status']->value))) {?>
   AND u.status = :status
<?php }
if ((isset($_smarty_tpl->tpl_vars['email']->value))) {?>
   AND up.email LIKE CONCAT('%', :email, '%')
<?php }
if ((isset($_smarty_tpl->tpl_vars['full_name']->value))) {?>
   AND up.full_name LIKE CONCAT('%', :full_name, '%')
<?php }
if ((isset($_smarty_tpl->tpl_vars['order_by']->value))) {?>
 ORDER BY <?php echo $_smarty_tpl->tpl_vars['order_by']->value;?>

<?php } else { ?>
 ORDER BY u.created_at DESC
         ,u.user_id ASC
<?php }
if ((isset($_smarty_tpl->tpl_vars['limit']->value))) {?>
 LIMIT :limit
<?php }
if ((isset($_smarty_tpl->tpl_vars['offset']->value))) {?>
OFFSET :offset
<?php }
}
}
