<?php
/* Smarty version 3.1.36, created on 2020-04-19 16:36:54
  from '/var/www/app/Front/Model/sql/user/user.insert_01.sql' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9bff964336f5_41460320',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '8aaec9c0ef05b550bda28f195124b7644bfef4e5' => 
    array (
      0 => '/var/www/app/Front/Model/sql/user/user.insert_01.sql',
      1 => 1587511573,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e9bff964336f5_41460320 (Smarty_Internal_Template $_smarty_tpl) {
?>INSERT INTO user
(
       user_id
      ,login_id
      ,password
      ,status
      ,created_id
      ,updated_id
)
VALUES
(
       :user_id
      ,:login_id
      ,:password
      ,:status
      ,:created_id
      ,:updated_id
)
<?php }
}
