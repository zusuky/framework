<?php
/* Smarty version 3.1.36, created on 2020-04-19 20:46:22
  from '/var/www/app/Front/Model/sql/user_profile/user_profile.insert_01.sql' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9c3a0e251806_58538093',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9a2294231a5963c5ea3da97cc14ac30d03bc76a8' => 
    array (
      0 => '/var/www/app/Front/Model/sql/user_profile/user_profile.insert_01.sql',
      1 => 1587521315,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e9c3a0e251806_58538093 (Smarty_Internal_Template $_smarty_tpl) {
?>INSERT INTO user_profile
(
       user_profile_id
      ,user_id
      ,email
      ,last_name
      ,middle_name
      ,first_name
      ,full_name
      ,custom_profile
      ,created_id
      ,updated_id
)
VALUES
(
       :user_profile_id
      ,:user_id
      ,:email
      ,:last_name
      ,:middle_name
      ,:first_name
      ,:full_name
      ,:custom_profile
      ,:created_id
      ,:updated_id
)
<?php }
}
