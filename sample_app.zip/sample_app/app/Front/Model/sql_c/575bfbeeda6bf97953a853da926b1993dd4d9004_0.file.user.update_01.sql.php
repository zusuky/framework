<?php
/* Smarty version 3.1.36, created on 2020-04-19 13:14:38
  from '/var/www/app/Front/Model/sql/user/user.update_01.sql' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9bd02ec2b559_43525716',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '575bfbeeda6bf97953a853da926b1993dd4d9004' => 
    array (
      0 => '/var/www/app/Front/Model/sql/user/user.update_01.sql',
      1 => 1587484915,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e9bd02ec2b559_43525716 (Smarty_Internal_Template $_smarty_tpl) {
?>UPDATE user
   SET loggedin_at = CURRENT_TIMESTAMP
 WHERE user_id = :user_id
<?php }
}
