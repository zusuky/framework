<?php
/* Smarty version 3.1.36, created on 2020-04-19 20:45:07
  from '/var/www/app/Front/Model/sql/user/user.select_02.sql' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9c39c3b4d9b5_36402693',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a43b036e3d125f296ce416c01d6a9f334680a436' => 
    array (
      0 => '/var/www/app/Front/Model/sql/user/user.select_02.sql',
      1 => 1587518718,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e9c39c3b4d9b5_36402693 (Smarty_Internal_Template $_smarty_tpl) {
?>SELECT *
  FROM user
 WHERE login_id = :login_id
<?php }
}
