<?php

class Auth {

    /**
     * ログインする。
     *
     * @param  string  $login_id  ログインID
     * @param  string  $password  パスワード
     * @return  boolean
     */
    public static function login($login_id, $password) : bool
    {
        $model_user = Model_user::forge();
        $model_user_profile = Model_user_profile::forge();

        $user = $model_user->findByLoginId($login_id);

        if (count($user) == 0) {
            return false;
        }
        if ($user['status'] == UserStatusConst::INVALID) {
            return false;
        }
        if (Crypt::decrypt(Arr::get($user, 'password')) != $password) {
            return false;
        }

        $model_user->updateLoggedInAt(Arr::get($user, 'user_id'));

        $user_profile = $model_user_profile->findByUserId(Arr::get($user, 'user_id'));

        if (count($user_profile) == 0) {
            return false;
        }

        $auth = [
            'user_id' => Arr::get($user, 'user_id'),
            'login_id' => Arr::get($user, 'login_id'),
            'email' => Arr::get($user_profile, 'email'),
            'last_name' => Arr::get($user_profile, 'last_name'),
            'middle_name' => Arr::get($user_profile, 'middle_name'),
            'first_name' => Arr::get($user_profile, 'first_name'),
            'full_name' => Arr::get($user_profile, 'full_name'),
            'status' => Arr::get($user_profile, 'status'),
        ];

        Session::set('auth', $auth);
        Session::regenerateId();

        return true;
    }

    /**
     * 認証情報をリフレッシュする。
     *
     * @param  string  $user_id  ユーザーID
     * @return  boolean
     */
    public static function reflesh($user_id) : bool
    {
        $model_user = Model_user::forge();
        $model_user_profile = Model_user_profile::forge();

        $user = $model_user->find($user_id);

        if (count($user) == 0) {
            return false;
        }
        if ($user['status'] == UserStatusConst::INVALID) {
            return false;
        }

        $user_profile = $model_user_profile->findByUserId($user_id);

        if (count($user_profile) == 0) {
            return false;
        }

        $auth = [
            'user_id' => Arr::get($user, 'user_id'),
            'login_id' => Arr::get($user, 'login_id'),
            'email' => Arr::get($user_profile, 'email'),
            'last_name' => Arr::get($user_profile, 'last_name'),
            'middle_name' => Arr::get($user_profile, 'middle_name'),
            'first_name' => Arr::get($user_profile, 'first_name'),
            'full_name' => Arr::get($user_profile, 'full_name'),
            'status' => Arr::get($user_profile, 'status'),
        ];

        Session::set('auth', $auth);
        Session::regenerateId();

        return true;
    }

    /**
     * ログアウトする。
     */
    public static function logout() : void
    {
        Session::delete('auth');
        Session::regenerateId();
    }

    /**
     * ログイン済みか判定する。
     *
     * @return  boolean
     */
    public static function isLoggedin() : bool
    {
        return Session::keyExists('auth');
    }

    /**
     * ユーザーIDを取得する。
     *
     * @return  string
     */
    public static function getUserId() : string
    {
        return Session::keyExists('auth.user_id') ? Session::get('auth.user_id') : '';
    }

    /**
     * ログインIDを取得する。
     *
     * @return  string
     */
    public static function getLoginId() : string
    {
        return Session::keyExists('auth.login_id') ? Session::get('auth.login_id') : '';
    }

    /**
     * メールアドレスを取得する。
     *
     * @return  string
     */
    public static function getEmail() : string
    {
        return Session::keyExists('auth.email') ? Session::get('auth.email') : '';
    }

    /**
     * ラストネームを取得する。
     *
     * @return  string
     */
    public static function getLastName() : string
    {
        return Session::keyExists('auth.last_name') ? Session::get('auth.last_name') : '';
    }

    /**
     * ミドルネームを取得する。
     *
     * @return  string
     */
    public static function getMiddleName() : string
    {
        return Session::keyExists('auth.middle_name') ? Session::get('auth.middle_name') : '';
    }

    /**
     * ファーストネームを取得する。
     *
     * @return  string
     */
    public static function getFirstName() : string
    {
        return Session::keyExists('auth.first_name') ? Session::get('auth.first_name') : '';
    }

    /**
     * フルネームを取得する。
     *
     * @return  string
     */
    public static function getFullName() : string
    {
        return Session::keyExists('auth.full_name') ? Session::get('auth.full_name') : '';
    }

    /**
     * ステータスを取得する。
     *
     * @return  string
     */
    public static function getStatus() : string
    {
        return Session::keyExists('auth.status') ? Session::get('auth.status') : '';
    }

}

