<?php

class Helper {

    /**
     * 年の配列を取得する。
     *
     * @param  string  $sort  asc:昇順|desc:降順（省略時はasc）
     * @return  array
     */
    public static function yearList($sort = 'asc') : array
    {
        $minYear = date('Y') - 100;
        $maxYear = date('Y');
        $arr = [];
        $loopCnt = (int) $maxYear - (int) $minYear;
        for ($i = 0; $i <= (int)$loopCnt; $i++) {
            if ($sort == 'desc') {
                $v = (string)((int)$maxYear - $i);
            } else {
                $v = (string)((int)$minYear + $i);
            }
            $arr[$v] = $v;
        }
        return $arr;
    }

    /**
     * 年の配列を取得する。（クレジットカード用）
     *
     * @return  array
     */
    public static function yearListCredit() : array
    {
        $minYear = date('Y');
        $maxYear = date('Y') + 30;
        $arr = [];
        $loopCnt = (int) $maxYear - (int) $minYear;
        for ($i = 0; $i <= (int)$loopCnt; $i++) {
            $v = (string)((int)$minYear + $i);
            $arr[$v] = $v;
        }
        return $arr;
    }

    /**
     * 月の配列を取得する。
     *
     * @param  boolean  $padding  0埋めするかどうか（省略時はtrue）
     * @return  array
     */
    public static function monthList($padding = true) : array
    {
        $arr = [];
        for ($i = 1; $i <= 12; $i++) {
            $v = (string)$i;
            if ($padding) {
                $v = str_pad($v, 2, '0', STR_PAD_LEFT);
            }
            $arr[$v] = $v;
        }
        return $arr;
    }

    /**
     * 日の配列を取得する。
     *
     * @param  boolean  $padding  0埋めするかどうか（省略時はtrue）
     * @return  array
     */
    public static function dateList($padding = true) : array
    {
        $arr = [];
        for ($i = 1; $i <= 31; $i++) {
            $v = (string)$i;
            if ($padding) {
                $v = str_pad($v, 2, '0', STR_PAD_LEFT);
            }
            $arr[$v] = $v;
        }
        return $arr;
    }

    /**
     * マスキングする。
     *
     * @param  string  $val       対象文字列
     * @param  string  $maskChar  置き換え文字（省略時は*）
     * @return  string
     */
    public static function mask($val, $maskChar = '*') : string
    {
        if (is_null($val) || mb_strlen($val) == 0) {
            return '';
        }
        $rtn = str_repeat($maskMark, mb_strlen($val));
        return $rtn;
    }

    /**
     * クレジットカード番号のマスキングする。
     *
     * @param  string  $val       対象文字列
     * @param  string  $maskChar  置き換え文字（省略時は*）
     * @return  string
     */
    public static function maskCreditNumber($val, $maskChar = '*') : string
    {
        if (is_null($val) || mb_strlen($val) <= 3) {
            return '';
        }
        $rtn = str_repeat($maskMark, mb_strlen($val) - 4) . mb_substr($val, -4);
        return $rtn;
    }

    /**
     * 半角数字のランダム文字列を作成する。
     *
     * @param  int  $length  桁数
     * @return  string
     */
    public static function randNum($length) : string
    {
        $strArr = array_merge(range('0', '9'));
        $arrlen = count($strArr)-1;
        $rtn = null;
        for ($i = 0; $i < (int)$length; $i++) {
            $rtn .= $strArr[mt_rand(0, $arrlen)];
        }
        return $rtn;
    }

    /**
     * 英字のランダム文字列を作成する。
     *
     * @param  int  $length  桁数
     * @return  string
     */
    public static function randAlpha($length) : string
    {
        $strArr = array_merge(range('a', 'z'), range('A', 'Z'));
        $arrlen = count($strArr)-1;
        $rtn = null;
        for ($i = 0; $i < (int)$length; $i++) {
            $rtn .= $strArr[mt_rand(0, $arrlen)];
        }
        return $rtn;
    }

    /**
     * 半角英数字のランダム文字列を作成する。
     *
     * @param  int  $length  桁数
     * @return  string
     */
    public static function randAlphaNum($length) : string
    {
        $strArr = array_merge(range('a', 'z'), range('A', 'Z'), range('0', '9'));
        $arrlen = count($strArr)-1;
        $rtn = null;
        for ($i = 0; $i < (int)$length; $i++) {
            $rtn .= $strArr[mt_rand(0, $arrlen)];
        }
        return $rtn;
    }

    /**
     * SJISチェックでエラーとなるハイフンを置き換える。
     *
     * @param  string  $val  対象文字列
     * @return  string
     */
    public static function convHyphen($val) : string
    {
        return str_replace('－', 'ー', $val);
    }

    /**
     * 空白をトリムする。
     *
     * @param  string  $val  対象文字列
     * @return  string
     */
    public static function trim($val) : string
    {
        return trim(mb_convert_kana($val, 's'));
    }

    /**
     * 左埋めする。
     *
     * @param  string $val      対象文字列
     * @param  string $pad_str  埋める文字列
     * @param  string $pad_len  埋める長さ
     * @return  string
     */
    public static function lpad($val, $pad_len, $pad_str) : string
    {
        if (Check::isEmpty($val)) {
            return $val;
        }
        return str_pad($val, $pad_len, $pad_str, STR_PAD_LEFT);
    }

    /**
     * 右埋めする。
     *
     * @param  string $val      対象文字列
     * @param  string $pad_str  埋める文字列
     * @param  string $pad_len  埋める長さ
     * @return  string
     */
    public static function rpad($val, $pad_len, $pad_str) : string
    {
        if (Check::isEmpty($val)) {
            return $val;
        }
        return str_pad($val, $pad_len, $pad_str, STR_PAD_RIGHT);
    }

}

