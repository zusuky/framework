<?php

class AdminUserRoleConst
{

    const ADMINISTRATOR = 'administrator';
    const MANAGER       = 'manager';
    const GENERAL       = 'general';
    const LIST = [
        self::ADMINISTRATOR => 'システム管理者',
        self::MANAGER       => '管理者',
        self::GENERAL       => '一般ユーザー',
    ];

    /**
     * 定数値に対する名称を取得する。
     *
     * @param  string  $constValue  定数値
     * @return  string
     */
    public static function getConstName($constValue) : string
    {
    	if (Check::isEmpty($constValue)) {
    		return '';
    	}
    	return Arr::get(self::LIST, $constValue);
    }
}