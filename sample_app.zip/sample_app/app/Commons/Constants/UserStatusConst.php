<?php

class UserStatusConst
{

    const VALID   = '0';
    const INVALID = '1';
    const LIST = [
        self::VALID   => '有効',
        self::INVALID => '無効',
    ];

    /**
     * 定数値に対する名称を取得する。
     *
     * @param  string  $constValue  定数値
     * @return  string
     */
    public static function getConstName($constValue) : string
    {
    	if (Check::isEmpty($constValue)) {
    		return '';
    	}
    	return Arr::get(self::LIST, $constValue);
    }
}