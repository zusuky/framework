<?php

class Model_admin_user extends Model {

	/** @ver  string  SQLファイル格納ディレクトリ名 */
	protected string $sql_dirname = 'admin_user';

	public function create($admin_user) : int
	{
		$sql_params = SQLParameter::forge();
		$sql_params->add('admin_user_id', Arr::get($admin_user, 'admin_user_id'))
				->add('login_id', Arr::get($admin_user, 'login_id'))
				->add('password', Arr::get($admin_user, 'password'))
				->add('email', Arr::get($admin_user, 'email'))
				->add('name', Arr::get($admin_user, 'name'))
				->add('role', Arr::get($admin_user, 'role'))
				->add('status', Arr::get($admin_user, 'status'))
				->add('created_id', Arr::get($admin_user, 'created_id'))
				->add('updated_id', Arr::get($admin_user, 'updated_id'));

		return $this->nonQueryByFile('admin_user.insert_01.sql', $sql_params);
	}

	public function find($admin_user_id) : array
	{
		$sql_params = SQLParameter::forge();
		$sql_params->add('admin_user_id', $admin_user_id);

		return $this->queryFirstByFile('admin_user.select_01.sql', $sql_params);
	}

	public function findByLoginId($login_id) : array
	{
		$sql_params = SQLParameter::forge();
		$sql_params->add('login_id', $login_id);

		return $this->queryFirstByFile('admin_user.select_02.sql', $sql_params);
	}

	public function where($condition) : array
	{
		$sql_params = SQLParameter::forge();
		if (Arr::keyExists($condition, 'login_id')) {
			$sql_params->add('login_id', Arr::get($condition, 'login_id'));
		}
		if (Arr::keyExists($condition, 'email')) {
			$sql_params->add('email', Arr::get($condition, 'email'));
		}
		if (Arr::keyExists($condition, 'name')) {
			$sql_params->add('name', Arr::get($condition, 'name'));
		}
		if (Arr::keyExists($condition, 'status')) {
			$sql_params->add('status', Arr::get($condition, 'status'));
		}
		if (Arr::keyExists($condition, 'order_by')) {
			$sql_params->addAssign('order_by', Arr::get($condition, 'order_by'));
		}
		if (Arr::keyExists($condition, 'limit')) {
			$sql_params->add('limit', Arr::get($condition, 'limit'));
		}
		if (Arr::keyExists($condition, 'offset')) {
			$sql_params->add('offset', Arr::get($condition, 'offset'));
		}

		return $this->queryByFile('admin_user.select_03.sql', $sql_params);
	}

	public function updateLoggedInAt($admin_user_id) : int
	{
		$sql_params = SQLParameter::forge();
		$sql_params->add('admin_user_id', $admin_user_id);

		return $this->nonQueryByFile('admin_user.update_01.sql', $sql_params);
	}

}

