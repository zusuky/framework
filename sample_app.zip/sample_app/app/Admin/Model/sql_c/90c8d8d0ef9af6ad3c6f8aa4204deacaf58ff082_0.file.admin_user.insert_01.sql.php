<?php
/* Smarty version 3.1.36, created on 2020-04-20 10:33:06
  from '/var/www/app/Admin/Model/sql/admin_user/admin_user.insert_01.sql' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9cfbd24d9665_77064428',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '90c8d8d0ef9af6ad3c6f8aa4204deacaf58ff082' => 
    array (
      0 => '/var/www/app/Admin/Model/sql/admin_user/admin_user.insert_01.sql',
      1 => 1587517160,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e9cfbd24d9665_77064428 (Smarty_Internal_Template $_smarty_tpl) {
?>INSERT INTO admin_user
(
       admin_user_id
      ,login_id
      ,password
      ,email
      ,name
      ,role
      ,status
      ,created_id
      ,updated_id
)
VALUES
(
       :admin_user_id
      ,:login_id
      ,:password
      ,:email
      ,:name
      ,:role
      ,:status
      ,:created_id
      ,:updated_id
)
<?php }
}
