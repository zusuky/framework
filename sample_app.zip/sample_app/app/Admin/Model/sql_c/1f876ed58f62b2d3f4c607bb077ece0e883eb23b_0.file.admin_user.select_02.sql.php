<?php
/* Smarty version 3.1.36, created on 2020-04-20 10:31:53
  from '/var/www/app/Admin/Model/sql/admin_user/admin_user.select_02.sql' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9cfb89bc05e1_38120107',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1f876ed58f62b2d3f4c607bb077ece0e883eb23b' => 
    array (
      0 => '/var/www/app/Admin/Model/sql/admin_user/admin_user.select_02.sql',
      1 => 1587518660,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e9cfb89bc05e1_38120107 (Smarty_Internal_Template $_smarty_tpl) {
?>SELECT *
  FROM admin_user
 WHERE login_id = :login_id
<?php }
}
