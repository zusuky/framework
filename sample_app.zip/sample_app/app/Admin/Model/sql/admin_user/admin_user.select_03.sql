SELECT *
  FROM admin_user
 WHERE 1 = 1
{if isset($login_id)}
   AND login_id LIKE CONCAT('%', :login_id, '%')
{/if}
{if isset($email)}
   AND email LIKE CONCAT('%', :email, '%')
{/if}
{if isset($name)}
   AND name LIKE CONCAT('%', :name, '%')
{/if}
{if isset($status)}
   AND status = :status
{/if}
{if isset($order_by)}
 ORDER BY {$order_by}
{else}
 ORDER BY created_at DESC
         ,admin_user_id ASC
{/if}
{if isset($limit)}
 LIMIT :limit
{/if}
{if isset($offset)}
OFFSET :offset
{/if}

