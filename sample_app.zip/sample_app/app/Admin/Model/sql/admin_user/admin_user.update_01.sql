UPDATE admin_user
   SET loggedin_at = CURRENT_TIMESTAMP
 WHERE admin_user_id = :admin_user_id
