SELECT *
  FROM admin_user
 WHERE admin_user_id = :admin_user_id
