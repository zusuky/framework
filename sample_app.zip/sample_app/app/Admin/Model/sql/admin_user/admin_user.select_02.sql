SELECT *
  FROM admin_user
 WHERE login_id = :login_id
