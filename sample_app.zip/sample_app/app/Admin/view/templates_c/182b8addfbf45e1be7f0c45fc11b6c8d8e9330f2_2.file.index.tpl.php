<?php
/* Smarty version 3.1.36, created on 2020-04-20 10:51:46
  from '/var/www/app/Admin/view/templates/home/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9d0032ac5af9_82523000',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '182b8addfbf45e1be7f0c45fc11b6c8d8e9330f2' => 
    array (
      0 => '/var/www/app/Admin/view/templates/home/index.tpl',
      1 => 1587609464,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e9d0032ac5af9_82523000 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_1004510905e9d0032ac4a74_31152371', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, '../commons/layout/app.tpl');
}
/* {block 'content'} */
class Block_1004510905e9d0032ac4a74_31152371 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_1004510905e9d0032ac4a74_31152371',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <div class="pb-5">
    	<h1 class="pb-5 display-3 text-center">Zusuky</h1>
        <p class="pb-3 text-center">ヤンキーWEB職人のためのフレームワーク。</p>
        <p class="text-center">PHPに支障はありません。楽しくコーディングし、新しい息吹を楽しんでください。</p>
    </div>

<?php
}
}
/* {/block 'content'} */
}
