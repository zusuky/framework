<?php
/* Smarty version 3.1.34-dev-7, created on 2020-04-18 14:14:46
  from '/var/www/app/admin/view/templates/layouts/app.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e9a8cc63c0a71_98455904',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '41c73ce06b01d4b95c187280cacea00088736418' => 
    array (
      0 => '/var/www/app/admin/view/templates/layouts/app.tpl',
      1 => 1587207703,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:./header.tpl' => 1,
    'file:./footer.tpl' => 1,
  ),
),false)) {
function content_5e9a8cc63c0a71_98455904 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
ob_start();
echo htmlspecialchars(Config::get('message_conf'), ENT_QUOTES, 'UTF-8');
$_prefixVariable1=ob_get_clean();
$_smarty_tpl->smarty->ext->configLoad->_loadConfigFile($_smarty_tpl, $_prefixVariable1, null, 0);
?>


<!DOCTYPE html>
<html>
<head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# article: http://ogp.me/ns/article#">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=0">
    <link rel="icon" type="image/png" href="<?php echo htmlspecialchars(Html::img('/favicon.png'), ENT_QUOTES, 'UTF-8');?>
">
    <link rel="apple-touch-icon" sizes="152x152" href="<?php echo htmlspecialchars(Html::img('apple-touch-icon.png'), ENT_QUOTES, 'UTF-8');?>
">
    <meta property="og:type" content="website">
    <meta property="og:description" content="">
    <meta property="og:title" content="">
    <meta property="og:url" content="">
    <meta property="og:image" content="<?php echo htmlspecialchars(Html::img('og-img.png'), ENT_QUOTES, 'UTF-8');?>
">
    <meta property="og:site_name" content="">
    <meta name="twitter:card" content="summary" />
    <title></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css" integrity="sha256-UzFD2WYH2U1dQpKDjjZK72VtPeWP50NoJjd26rnAdUI=" crossorigin="anonymous" />
    <link href="<?php echo htmlspecialchars(Html::css('app.css'), ENT_QUOTES, 'UTF-8');?>
" rel="stylesheet" type="text/css" media="all"/>
</head>
<body>
    <div class="wrap">
        <?php $_smarty_tpl->_subTemplateRender('file:./header.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
        <main>
            <div class="container py-5">
                <?php if (isset($_smarty_tpl->tpl_vars['is_small_content']->value)) {?>
                    <div class="row justify-content-center">
                        <div class="col-md-8 col-sm-12">
                            <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_13843583025e9a8cc63bc629_47020667', 'content');
?>

                        </div>
                    </div>
                <?php } else { ?>
                    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_10746166075e9a8cc63be596_05669818', 'content');
?>

                <?php }?>
            </div>
        </main>
        <?php $_smarty_tpl->_subTemplateRender('file:./footer.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
?>
    </div>
</body>
</html>
<?php }
/* {block 'content'} */
class Block_13843583025e9a8cc63bc629_47020667 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_13843583025e9a8cc63bc629_47020667',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'content'} */
/* {block 'content'} */
class Block_10746166075e9a8cc63be596_05669818 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_10746166075e9a8cc63be596_05669818',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'content'} */
}
