<?php
/* Smarty version 3.1.36, created on 2020-04-19 22:59:45
  from '/var/www/app/Admin/View/templates/auth/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9c59516e19d0_47981327',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '883e36b728ad4063bb32ec814b23d638e6cd0fa7' => 
    array (
      0 => '/var/www/app/Admin/View/templates/auth/index.tpl',
      1 => 1587534684,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../commons/form_components/text.tpl' => 1,
    'file:../commons/form_components/password.tpl' => 1,
  ),
),false)) {
function content_5e9c59516e19d0_47981327 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
$_smarty_tpl->_assignInScope('is_small_content', "1");?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_13861777045e9c5951682f69_05517412', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, '../commons/layout/app.tpl');
}
/* {block 'content'} */
class Block_13861777045e9c5951682f69_05517412 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_13861777045e9c5951682f69_05517412',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <?php echo '<script'; ?>
>
        $(function(){
            var init = function(){
                if ($('form .error-message').length) {
                    var position = $('form .error-message').first().offset().top -200;
                    
                    $('html, body').animate({scrollTop: position}, 800);
                    
                    $('.toast-error .toast-body').html('<?php echo htmlspecialchars($_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'errorValidation'), ENT_QUOTES, 'UTF-8');?>
');
                    
                    $('.toast-error').toast({ delay: 3000 });
                    
                    $('.toast-error').toast('show');
                }
            };
            var auth = function(){
                $('#form-main').submit();
            };
            init();
            $("#btn-auth").on('click', function(){
                auth();
            });
        });
    <?php echo '</script'; ?>
>

    <h1 class="page-header">
        ログイン
    </h1>

    <div class="bg-white shadow p-4">
        <form method="post" action="<?php echo htmlspecialchars(Html::url('auth/login'), ENT_QUOTES, 'UTF-8');?>
" id="form-main">
            <?php $_smarty_tpl->_subTemplateRender('file:../commons/form_components/text.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('label'=>'Login ID','name'=>"login_id",'value'=>$_smarty_tpl->tpl_vars['login_id']->value,'placeholder'=>"Enter Login ID"), 0, false);
?>
            <?php $_smarty_tpl->_subTemplateRender('file:../commons/form_components/password.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('label'=>'Password','name'=>"password",'value'=>$_smarty_tpl->tpl_vars['password']->value,'placeholder'=>"Enter Password"), 0, false);
?>
            <button type="button" class="btn btn-primary" id="btn-auth">ログイン</button>
        </form>
    </div>

<?php
}
}
/* {/block 'content'} */
}
