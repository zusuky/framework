<?php
/* Smarty version 3.1.36, created on 2020-04-19 22:59:45
  from '/var/www/app/Admin/View/templates/commons/form_components/password.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9c5951c1c6b9_49243203',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7ab8a691a06adca0eef799e6d6cb29c4df80ad8e' => 
    array (
      0 => '/var/www/app/Admin/View/templates/commons/form_components/password.tpl',
      1 => 1587533449,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e9c5951c1c6b9_49243203 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="form-group">
<?php if ((isset($_smarty_tpl->tpl_vars['label']->value))) {?>
    <label><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['label']->value, ENT_QUOTES, 'UTF-8');?>
</label>
<?php }
if ((isset($_smarty_tpl->tpl_vars['help_above']->value))) {?>
    <div class="form-text text-muted mt-0 mb-1"><?php echo $_smarty_tpl->tpl_vars['help_above']->value;?>
</div>
<?php }?>
    <input type="password" class="form-control" <?php if ((isset($_smarty_tpl->tpl_vars['name']->value))) {?>name="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['name']->value, ENT_QUOTES, 'UTF-8');?>
" <?php }
if ((isset($_smarty_tpl->tpl_vars['id']->value))) {?>id="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['id']->value, ENT_QUOTES, 'UTF-8');?>
" <?php }
if ((isset($_smarty_tpl->tpl_vars['value']->value))) {?>value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['value']->value, ENT_QUOTES, 'UTF-8');?>
" <?php } else { ?>value="" <?php }
if ((isset($_smarty_tpl->tpl_vars['placeholder']->value))) {?>placeholder="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['placeholder']->value, ENT_QUOTES, 'UTF-8');?>
" <?php }
if ((isset($_smarty_tpl->tpl_vars['maxlength']->value))) {?>maxlength="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['maxlength']->value, ENT_QUOTES, 'UTF-8');?>
" <?php }
if ((isset($_smarty_tpl->tpl_vars['readonly']->value))) {?>readonly <?php }
if ((isset($_smarty_tpl->tpl_vars['disabled']->value))) {?>disabled <?php }?>/>
<?php if ((isset($_smarty_tpl->tpl_vars['help_below']->value))) {?>
    <div class="form-text text-muted"><?php echo $_smarty_tpl->tpl_vars['help_below']->value;?>
</div>
<?php }
if ((isset($_smarty_tpl->tpl_vars['name']->value)) && (isset($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->tpl_vars['name']->value]))) {?>
    <div class="my-1 error-message"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->tpl_vars['name']->value], ENT_QUOTES, 'UTF-8');?>
</div>
<?php }?>
</div>
<?php }
}
