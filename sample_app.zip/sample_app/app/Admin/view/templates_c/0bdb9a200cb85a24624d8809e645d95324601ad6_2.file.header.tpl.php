<?php
/* Smarty version 3.1.34-dev-7, created on 2020-04-18 14:14:46
  from '/var/www/app/admin/view/templates/layouts/header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e9a8cc65d5724_53272568',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '0bdb9a200cb85a24624d8809e645d95324601ad6' => 
    array (
      0 => '/var/www/app/admin/view/templates/layouts/header.tpl',
      1 => 1587355302,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e9a8cc65d5724_53272568 (Smarty_Internal_Template $_smarty_tpl) {
?><header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow">
        <div class="container">
            <a class="navbar-brand" href="<?php echo htmlspecialchars(Html::url(), ENT_QUOTES, 'UTF-8');?>
">
                <img src="<?php echo htmlspecialchars(Html::img('logo.png'), ENT_QUOTES, 'UTF-8');?>
"/> Zusuky Framework
            </a>
            <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#glovalNavTop" aria-controls="glovalNavTop" aria-expanded="false" aria-label="ナビゲーションの切替">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="glovalNavTop">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo htmlspecialchars(Html::url('help'), ENT_QUOTES, 'UTF-8');?>
">概要</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo htmlspecialchars(Html::url('help/config'), ENT_QUOTES, 'UTF-8');?>
">Config</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo htmlspecialchars(Html::url('help/core'), ENT_QUOTES, 'UTF-8');?>
">Core(zcore)</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo htmlspecialchars(Html::url('help/design'), ENT_QUOTES, 'UTF-8');?>
">画面デザイン</a>
                    </li>
                </ul>
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item dropdown">
                        <a href="" class="nav-link dropdown-toggle" role="button" data-toggle="dropdown" id="navbarDropdownMenuLink" aria-haspopup="true" aria-expanded="false">
                            <i class="fas fa-user"></i> Welcome Zusuky <span class="caret"></span>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <a class="dropdown-item" href="#">ユーザ情報編集</a>
                            <a class="dropdown-item" href="#">ログアウト</a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>
<?php }
}
