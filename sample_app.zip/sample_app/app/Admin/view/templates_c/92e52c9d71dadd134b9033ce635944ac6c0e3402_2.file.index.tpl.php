<?php
/* Smarty version 3.1.36, created on 2020-04-20 10:09:15
  from '/var/www/app/Admin/view/templates/errors/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9cf63bda5266_19620991',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '92e52c9d71dadd134b9033ce635944ac6c0e3402' => 
    array (
      0 => '/var/www/app/Admin/view/templates/errors/index.tpl',
      1 => 1587485306,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e9cf63bda5266_19620991 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
$_smarty_tpl->_assignInScope('is_small_content', "1");?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_12231822945e9cf63bd69552_25631795', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, '../commons/layout/app.tpl');
}
/* {block 'content'} */
class Block_12231822945e9cf63bd69552_25631795 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_12231822945e9cf63bd69552_25631795',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <h1 class="page-header text-danger">
        <i class="fa fa-exclamation-triangle"></i> エラー
    </h1>

    <article>
        <?php if ((isset($_smarty_tpl->tpl_vars['error_message']->value))) {?>
            <?php ob_start();
echo htmlspecialchars($_smarty_tpl->tpl_vars['error_message']->value, ENT_QUOTES, 'UTF-8');
$_prefixVariable1 = ob_get_clean();
echo nl2br($_prefixVariable1);?>

        <?php }?>
    </article>

<?php
}
}
/* {/block 'content'} */
}
