<?php /* Smarty version 3.1.34-dev-7, created on 2020-04-18 14:14:46
         compiled from '/var/www/app/admin/view/configs/message_ja.conf' */ ?>
<?php
/* Smarty version 3.1.34-dev-7, created on 2020-04-18 14:14:46
  from '/var/www/app/admin/view/configs/message_ja.conf' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e9a8cc652cd31_68360828',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ee7e7e44bff8147842a9876e3dcc07c407caad17' => 
    array (
      0 => '/var/www/app/admin/view/configs/message_ja.conf',
      1 => 1587377368,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e9a8cc652cd31_68360828 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->smarty->ext->configLoad->_loadConfigVars($_smarty_tpl, array (
  'sections' => 
  array (
  ),
  'vars' => 
  array (
    'required' => '%sを入力してください。',
    'requiredSelect' => '%sを選択してください。',
    'alpha' => '%sは半角英字のみで入力してください。',
    'number' => '%sは半角数字のみで入力してください。',
    'alphanumber' => '%sは半角英数字のみで入力してください。',
    'mixed' => '%sは、半角英字と半角数字をそれぞれ1文字以上含む必要があります。',
    'date' => '%sは日付で入力してください。',
    'time' => '%sは時分で入力してください。',
    'invalid' => '%sが無効です。',
    'invalidFormat' => '%sの形式が不正です。',
    'cannotBeUsed' => '%sに使用できない文字を含んでいます。',
    'lengthMin' => '%sは%s文字以上で入力してください。',
    'lengthMax' => '%sは%s文字以内で入力してください。',
    'lengthRange' => '%sは%s文字以上、%s文字以内で入力してください。',
    'lengthExact' => '%sは%s文字で入力してください。',
    'lengthMinNumber' => '%sは%s桁以上で入力してください。',
    'lengthMaxNumber' => '%sは%s桁以内で入力してください。',
    'lengthRangeNumber' => '%sは%s桁以上、%s桁以内で入力してください。',
    'lengthExactNumber' => '%sは%s桁で入力してください。',
    'numberMin' => '%sは%s以上で入力してください。',
    'numberMax' => '%sは%s以内で入力してください。',
    'numberRange' => '%sは%s以上、%s以内で入力してください。',
    'matchValue' => '%sと%sが一致しません。',
    'zenkaku' => '%sは全角で入力してください。',
    'zenkakuKana' => '%sは全角カナで入力してください。',
    'zenkakuNonSymbol' => '%sは全角（ハイフン以外の記号なし）で入力してください。',
    'zenkakuKanaNonSymbol' => '%sは全角カナ（ハイフン以外の記号なし）で入力してください。',
    'greaterThan' => '%sは%sより大きい値で入力してください。',
    'greaterEqual' => '%sは%s以上で入力してください。',
    'errorSessionTimeout' => 'セッションがタイムアウトしました。
お手数ですが操作をはじめからやり直してください。',
    'errorDoubleTransmission' => '二重送信はできません。',
    'errorInvalidOperation' => '不正な画面遷移、または、操作が行われました。
お手数ですが操作をはじめからやり直してください。',
    'errorInvalidUrl' => '無効なURLです。',
    'errorSystem' => '申し訳ありません。ただいまアクセスが集中し、大変混雑しております。
お手数ですが、しばらく時間をおいてから再度アクセスしてください。',
    'errorValidation' => '入力内容に誤りがあります。赤字の項目を修正してください。',
    'errorConnect' => '通信に失敗しました。',
  ),
));
}
}
