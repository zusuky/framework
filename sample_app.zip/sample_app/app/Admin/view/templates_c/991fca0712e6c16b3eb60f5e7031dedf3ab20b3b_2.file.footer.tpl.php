<?php
/* Smarty version 3.1.34-dev-7, created on 2020-04-18 14:14:46
  from '/var/www/app/admin/view/templates/layouts/footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e9a8cc6659539_16674283',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '991fca0712e6c16b3eb60f5e7031dedf3ab20b3b' => 
    array (
      0 => '/var/www/app/admin/view/templates/layouts/footer.tpl',
      1 => 1587377689,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e9a8cc6659539_16674283 (Smarty_Internal_Template $_smarty_tpl) {
?><footer class="pb-5">
    <div class="container">
        <ul class="nav d-flex justify-content-center flex-wrap mb-2">
            <li class="nav-item">
                <a class="nav-link" href="https://www.rococo.co.jp/" target="_blank">株式会社ロココ</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="http://13.113.74.195/sse/Zusuky" target="_blank">Zusuky</a>
            </li>
        </ul>
        <div class="d-flex justify-content-center">
            Copyright © ROCOCO Co., Ltd. All rights reserved.
        </div>
    </div>
</footer>
<?php }
}
