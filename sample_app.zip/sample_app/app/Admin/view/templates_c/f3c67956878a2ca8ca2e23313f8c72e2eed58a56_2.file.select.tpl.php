<?php
/* Smarty version 3.1.36, created on 2020-04-20 10:14:02
  from '/var/www/app/Admin/view/templates/commons/form_components/select.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9cf75a0182c2_00954678',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f3c67956878a2ca8ca2e23313f8c72e2eed58a56' => 
    array (
      0 => '/var/www/app/Admin/view/templates/commons/form_components/select.tpl',
      1 => 1587533457,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e9cf75a0182c2_00954678 (Smarty_Internal_Template $_smarty_tpl) {
?><div class="form-group">
<?php if ((isset($_smarty_tpl->tpl_vars['label']->value))) {?>
    <label><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['label']->value, ENT_QUOTES, 'UTF-8');?>
</label>
<?php }
if ((isset($_smarty_tpl->tpl_vars['help_above']->value))) {?>
    <div class="form-text text-muted mt-0 mb-1"><?php echo $_smarty_tpl->tpl_vars['help_above']->value;?>
</div>
<?php }?>
	<select class="form-control" <?php if ((isset($_smarty_tpl->tpl_vars['name']->value))) {?>name="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['name']->value, ENT_QUOTES, 'UTF-8');?>
" <?php }?> <?php if ((isset($_smarty_tpl->tpl_vars['id']->value))) {?>id="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['id']->value, ENT_QUOTES, 'UTF-8');?>
" <?php }?>>
<?php if ((isset($_smarty_tpl->tpl_vars['add_empty']->value))) {?>
		<option value="">--</option>
<?php }
if ((isset($_smarty_tpl->tpl_vars['options']->value)) && !empty($_smarty_tpl->tpl_vars['options']->value)) {?>
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['options']->value, 'val', false, 'key');
$_smarty_tpl->tpl_vars['val']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['val']->value) {
$_smarty_tpl->tpl_vars['val']->do_else = false;
?>
        <option value="<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['key']->value, ENT_QUOTES, 'UTF-8');?>
" <?php if ((isset($_smarty_tpl->tpl_vars['selected']->value)) && $_smarty_tpl->tpl_vars['selected']->value == $_smarty_tpl->tpl_vars['key']->value) {?>selected<?php }?>><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['val']->value, ENT_QUOTES, 'UTF-8');?>
</option>
    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
}?>
	</select>
<?php if ((isset($_smarty_tpl->tpl_vars['help_below']->value))) {?>
    <div class="form-text text-muted"><?php echo $_smarty_tpl->tpl_vars['help_below']->value;?>
</div>
<?php }
if ((isset($_smarty_tpl->tpl_vars['name']->value)) && (isset($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->tpl_vars['name']->value]))) {?>
    <div class="my-1 error-message"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['errors']->value[$_smarty_tpl->tpl_vars['name']->value], ENT_QUOTES, 'UTF-8');?>
</div>
<?php }?>
</div><?php }
}
