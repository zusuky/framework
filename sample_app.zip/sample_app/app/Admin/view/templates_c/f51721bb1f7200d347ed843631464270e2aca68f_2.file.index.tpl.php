<?php
/* Smarty version 3.1.36, created on 2020-04-19 23:02:05
  from '/var/www/app/Admin/View/templates/errors/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9c59dd9e0981_72794122',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f51721bb1f7200d347ed843631464270e2aca68f' => 
    array (
      0 => '/var/www/app/Admin/View/templates/errors/index.tpl',
      1 => 1587485306,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e9c59dd9e0981_72794122 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
$_smarty_tpl->_assignInScope('is_small_content', "1");?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_5074704705e9c59dd8dbff3_12461499', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, '../commons/layout/app.tpl');
}
/* {block 'content'} */
class Block_5074704705e9c59dd8dbff3_12461499 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_5074704705e9c59dd8dbff3_12461499',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <h1 class="page-header text-danger">
        <i class="fa fa-exclamation-triangle"></i> エラー
    </h1>

    <article>
        <?php if ((isset($_smarty_tpl->tpl_vars['error_message']->value))) {?>
            <?php ob_start();
echo htmlspecialchars($_smarty_tpl->tpl_vars['error_message']->value, ENT_QUOTES, 'UTF-8');
$_prefixVariable1 = ob_get_clean();
echo nl2br($_prefixVariable1);?>

        <?php }?>
    </article>

<?php
}
}
/* {/block 'content'} */
}
