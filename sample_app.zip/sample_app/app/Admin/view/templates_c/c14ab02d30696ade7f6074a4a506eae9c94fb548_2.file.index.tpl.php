<?php
/* Smarty version 3.1.36, created on 2020-04-20 10:38:19
  from '/var/www/app/Admin/view/templates/auth/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9cfd0b11f2d5_21750482',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c14ab02d30696ade7f6074a4a506eae9c94fb548' => 
    array (
      0 => '/var/www/app/Admin/view/templates/auth/index.tpl',
      1 => 1587608714,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../commons/form_components/text.tpl' => 1,
    'file:../commons/form_components/password.tpl' => 1,
  ),
),false)) {
function content_5e9cfd0b11f2d5_21750482 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
$_smarty_tpl->_assignInScope('is_small_content', "1");?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_17406727535e9cfd0b1046b9_59533021', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, '../commons/layout/app.tpl');
}
/* {block 'content'} */
class Block_17406727535e9cfd0b1046b9_59533021 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_17406727535e9cfd0b1046b9_59533021',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <?php echo '<script'; ?>
>
        $(function(){
            var init = function(){
                if ($('#error-unauthorized').length) {
                    $('.toast-error .toast-body').text($('#error-unauthorized').text());
                    
                    $('.toast-error').toast({ delay: 3000 });
                    
                    $('.toast-error').toast('show');
                }
                if ($('form .error-message').length) {
                    var position = $('form .error-message').first().offset().top -200;
                    
                    $('html, body').animate({scrollTop: position}, 800);
                    
                    $('.toast-error .toast-body').html('<?php echo htmlspecialchars($_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'errorValidation'), ENT_QUOTES, 'UTF-8');?>
');
                    
                    $('.toast-error').toast({ delay: 3000 });
                    
                    $('.toast-error').toast('show');
                }
            };
            var auth = function(){
                $('#form-main').submit();
            };
            init();
            $("#btn-auth").on('click', function(){
                auth();
            });
        });
    <?php echo '</script'; ?>
>

    <h1 class="page-header">
        ログイン
    </h1>

    <?php if ((isset($_smarty_tpl->tpl_vars['errors']->value['unauthorized']))) {?>
        <div class="d-none" id="error-unauthorized"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['errors']->value['unauthorized'], ENT_QUOTES, 'UTF-8');?>
</div>
    <?php }?>

    <div class="bg-white shadow p-4">
        <form method="post" action="<?php echo htmlspecialchars(Html::url('auth/login'), ENT_QUOTES, 'UTF-8');?>
" id="form-main">
            <?php $_smarty_tpl->_subTemplateRender('file:../commons/form_components/text.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('label'=>'Login ID','name'=>"login_id",'value'=>$_smarty_tpl->tpl_vars['login_id']->value,'placeholder'=>"Enter Login ID"), 0, false);
?>
            <?php $_smarty_tpl->_subTemplateRender('file:../commons/form_components/password.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('label'=>'Password','name'=>"password",'value'=>$_smarty_tpl->tpl_vars['password']->value,'placeholder'=>"Enter Password"), 0, false);
?>
            <button type="button" class="btn btn-primary" id="btn-auth">ログイン</button>
        </form>
    </div>

<?php
}
}
/* {/block 'content'} */
}
