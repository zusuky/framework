<?php
/* Smarty version 3.1.36, created on 2020-04-20 10:29:38
  from '/var/www/app/Admin/view/templates/admin_user/create.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.36',
  'unifunc' => 'content_5e9cfb02ded982_17505501',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '39d5af8b66c25426d3512eb23bd22322cf144776' => 
    array (
      0 => '/var/www/app/Admin/view/templates/admin_user/create.tpl',
      1 => 1587608239,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:../commons/form_components/text.tpl' => 2,
    'file:../commons/form_components/password.tpl' => 2,
    'file:../commons/form_components/email.tpl' => 1,
    'file:../commons/form_components/select.tpl' => 1,
    'file:../commons/form_components/radio.tpl' => 1,
  ),
),false)) {
function content_5e9cfb02ded982_17505501 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_16430891885e9cfb02db3a52_23030937', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, '../commons/layout/app.tpl');
}
/* {block 'content'} */
class Block_16430891885e9cfb02db3a52_23030937 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_16430891885e9cfb02db3a52_23030937',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <?php echo '<script'; ?>
>
        $(function(){
            var init = function(){
                if ($('#error-conflict').length) {
                    $('.toast-error .toast-body').text($('#error-conflict').text());
                    
                    $('.toast-error').toast({ delay: 3000 });
                    
                    $('.toast-error').toast('show');
                }
                if ($('form .error-message').length) {
                    var position = $('form .error-message').first().offset().top -200;
                    
                    $('html, body').animate({scrollTop: position}, 800);
                    
                    $('.toast-error .toast-body').html('<?php echo htmlspecialchars($_smarty_tpl->smarty->ext->configLoad->_getConfigVariable($_smarty_tpl, 'errorValidation'), ENT_QUOTES, 'UTF-8');?>
');
                    
                    $('.toast-error').toast({ delay: 3000 });
                    
                    $('.toast-error').toast('show');
                }
            };
            var register = function(){
                $('#form-main').submit();
            };
            init();
            $("#btn-register").on('click', function(){
                register();
            });
        });
    <?php echo '</script'; ?>
>

    <h1 class="page-header">
        ユーザー登録
    </h1>

    <?php if ((isset($_smarty_tpl->tpl_vars['errors']->value['conflict']))) {?>
        <div class="d-none" id="error-conflict"><?php echo htmlspecialchars($_smarty_tpl->tpl_vars['errors']->value['conflict'], ENT_QUOTES, 'UTF-8');?>
</div>
    <?php }?>

    <div class="bg-white shadow p-4">
        <form method="post" action="<?php echo htmlspecialchars(Html::url('admin_user/create_save'), ENT_QUOTES, 'UTF-8');?>
" id="form-main">
            <?php $_smarty_tpl->_subTemplateRender('file:../commons/form_components/text.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('label'=>'Login ID','name'=>"login_id",'value'=>$_smarty_tpl->tpl_vars['login_id']->value,'maxlength'=>"20",'placeholder'=>"Enter Login ID",'help_below'=>"*Only single-byte alphanumeric characters"), 0, false);
?>
            <?php $_smarty_tpl->_subTemplateRender('file:../commons/form_components/password.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('label'=>'Password','name'=>"password",'value'=>$_smarty_tpl->tpl_vars['password']->value,'maxlength'=>"20",'placeholder'=>"Enter Password"), 0, false);
?>
            <?php $_smarty_tpl->_subTemplateRender('file:../commons/form_components/password.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('label'=>'Password confirmation','name'=>"password_confirmation",'value'=>$_smarty_tpl->tpl_vars['password_confirmation']->value,'maxlength'=>"20",'placeholder'=>"Enter Password confirmation"), 0, true);
?>
            <?php $_smarty_tpl->_subTemplateRender('file:../commons/form_components/email.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('label'=>'Email address','name'=>"email",'value'=>$_smarty_tpl->tpl_vars['email']->value,'maxlength'=>"100",'placeholder'=>"Enter Email address"), 0, false);
?>
            <?php $_smarty_tpl->_subTemplateRender('file:../commons/form_components/text.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('label'=>'Name','name'=>"name",'value'=>$_smarty_tpl->tpl_vars['name']->value,'maxlength'=>"20",'placeholder'=>"Enter Name"), 0, true);
?>
            <?php $_smarty_tpl->_subTemplateRender('file:../commons/form_components/select.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('label'=>'Role','name'=>"role",'add_empty'=>true,'options'=>AdminUserRoleConst::LIST,'selected'=>$_smarty_tpl->tpl_vars['role']->value), 0, false);
?>
            <?php $_smarty_tpl->_subTemplateRender('file:../commons/form_components/radio.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array('label'=>'Status','name'=>"status",'options'=>AdminUserStatusConst::LIST,'checked'=>$_smarty_tpl->tpl_vars['status']->value), 0, false);
?>
            <button type="button" class="btn btn-primary" id="btn-register">登録</button>
        </form>
    </div>

<?php
}
}
/* {/block 'content'} */
}
