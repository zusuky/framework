<?php
/* Smarty version 3.1.34-dev-7, created on 2020-04-18 14:16:49
  from '/var/www/app/admin/view/templates/home/index.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.34-dev-7',
  'unifunc' => 'content_5e9a8d41bfcf66_60228670',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '5c1fb215f0fe978e023792be35c19c8f33d5d298' => 
    array (
      0 => '/var/www/app/admin/view/templates/home/index.tpl',
      1 => 1587378197,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e9a8d41bfcf66_60228670 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_7497399715e9a8d41bfadd9_77232161', 'content');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, '../layouts/app.tpl');
}
/* {block 'content'} */
class Block_7497399715e9a8d41bfadd9_77232161 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_7497399715e9a8d41bfadd9_77232161',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <div class="pb-5">
    	<h1 class="pb-5 display-3 text-center">Zusuky</h1>
        <p class="pb-3 text-center">ヤンキーWEB職人のためのフレームワーク。</p>
        <p class="pb-3 text-center">PHPに支障はありません。楽しくコーディングし、新しい息吹を楽しんでください。</p>
        <p class="text-center">デフォルトで、管理画面もデフォルトも作れます。</p>
    </div>

    <article class="pb-5">
    </article>

<?php
}
}
/* {/block 'content'} */
}
