<?php

class Controller_admin_user extends Controller
{

    use ControllerTrait;

    /**
     * 登録画面表示
     */
    public function action_create() : void
    {
        try {

            $view = View::forge();
            $view->display('admin_user/create.tpl');

        } catch (Throwable $e) {
            fatalLog('想定外の例外が発生しました。', $e);
            $this->showSystemError();
        }
    }

    /**
     * 登録
     */
    public function action_create_save() : void
    {
        try {

            $errors = $this->validation();

            if (count($errors) > 0) {
                warnLog('validationエラーです。' . print_r($errors, true));
                $view = View::forge();
                $view->assignArr(Post::get());
                $view->assign('errors', $errors);
                $view->display('admin_user/create.tpl');
                return;
            }

            DB::beginTransaction();

            $model_admin_user = Model_admin_user::forge();

            $same_login_id_admin_user = $model_admin_user->findByLoginId(Post::get('login_id'));

            if (count($same_login_id_admin_user) > 0) {
                $errors = ['conflict' => 'A admin user with the same login ID already exists.'];
                warnLog('validationエラーです。' . print_r($errors, true));
                DB::rollback();
                $view = View::forge();
                $view->assignArr(Post::get());
                $view->assign('errors', $errors);
                $view->display('admin_user/create.tpl');
                return;
            }

            $admin_user_id = UuidCreator::create();

            $admin_user = [
                'admin_user_id' => $admin_user_id,
                'login_id' => Post::get('login_id'),
                'password' => Crypt::encrypt(Post::get('password')),
                'email' => Post::get('email'),
                'name' => Post::get('name'),
                'role' => Post::get('role'),
                'status' => Post::get('status'),
                'created_id' => Auth::getAdminUserId(),
                'updated_id' => Auth::getAdminUserId(),
            ];

            $model_admin_user->create($admin_user);

            DB::commit();

            Html::redirect(Html::url());

        } catch (Throwable $e) {
            fatalLog('想定外の例外が発生しました。', $e);
            $this->showSystemError();
        }
    }

    /**
     * validation
     *
     * @return  array
     */
    private function validation() : array
    {
        $validation = Validation::forge();

        // Login ID
        $validation->addItem('login_id', Post::get('login_id'))
                ->addRule('required', Message::get('required', ['Login ID']))
                ->addRule('maxLength[20]', Message::get('maxLength', ['Login ID', '20']));

        // Password
        $validation->addItem('password', Post::get('password'))
                ->addRule('required', Message::get('required', ['Password']))
                ->addRule('alphanumber', Message::get('alphanumber', ['Password']))
                ->addRule('rangeLength[8][20]', Message::get('lengthRange', ['Password', '8', '20']));

        // Password confirmation
        $validation->addItem('password_confirmation', Post::get('password_confirmation'))
                ->addRule('required', Message::get('required', ['Password confirmation']))
                ->addRule('alphanumber', Message::get('alphanumber', ['Password confirmation']))
                ->addRule('rangeLength[8][20]', Message::get('lengthRange', ['Password confirmation', '8', '20']))
                ->addRule('exact[' . Post::get('password') . ']', Message::get('matchValue', ['Password', 'Password confirmation']));

        // Email address
        $validation->addItem('email', Post::get('email'))
                ->addRule('required', Message::get('required', ['Email address']))
                ->addRule('email', Message::get('invalidFormat', ['Email address']));

        // Name
        $validation->addItem('name', Post::get('name'))
                ->addRule('required', Message::get('required', ['Name']))
                ->addRule('maxLength[20]', Message::get('maxLength', ['Name', '20']));

        // Role
        $validation->addItem('role', Post::get('role'))
                ->addRule('required', Message::get('requiredSelect', ['Role']));

        // Status
        $validation->addItem('status', Post::get('status'))
                ->addRule('required', Message::get('requiredSelect', ['Status']));

        return $validation->run();
    }

}
