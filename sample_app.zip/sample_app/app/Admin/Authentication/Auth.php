<?php

class Auth {

    /**
     * ログインする。
     *
     * @param  string  $login_id  ログインID
     * @param  string  $password  パスワード
     * @return  boolean
     */
    public static function login($login_id, $password) : bool
    {
        $model_admin_user = Model_admin_user::forge();

        $admin_user = $model_admin_user->findByLoginId($login_id);

        if (count($admin_user) == 0) {
            return false;
        }
        if ($admin_user['status'] == UserStatusConst::INVALID) {
            return false;
        }
        if (Crypt::decrypt(Arr::get($admin_user, 'password')) != $password) {
            return false;
        }

        $admin_auth = [
            'admin_user_id' => Arr::get($admin_user, 'admin_user_id'),
            'login_id' => Arr::get($admin_user, 'login_id'),
            'email' => Arr::get($admin_user, 'email'),
            'name' => Arr::get($admin_user, 'name'),
            'role' => Arr::get($admin_user, 'role'),
            'status' => Arr::get($admin_user, 'status'),
        ];

        Session::set('admin_auth', $admin_auth);
        Session::regenerateId();

        return true;
    }

    /**
     * 認証情報をリフレッシュする。
     *
     * @param  string  $user_id  ユーザーID
     * @return  boolean
     */
    public static function reflesh($admin_user_id) : bool
    {
        $model_admin_user = Model_admin_user::forge();

        $admin_user = $model_admin_user->find($admin_user_id);

        if (count($admin_user) == 0) {
            return false;
        }
        if ($admin_user['status'] == UserStatusConst::INVALID) {
            return false;
        }

        $admin_auth = [
            'admin_user_id' => Arr::get($admin_user, 'admin_user_id'),
            'login_id' => Arr::get($admin_user, 'login_id'),
            'email' => Arr::get($admin_user, 'email'),
            'name' => Arr::get($admin_user, 'name'),
            'role' => Arr::get($admin_user, 'role'),
            'status' => Arr::get($admin_user, 'status'),
        ];

        Session::set('admin_auth', $admin_auth);
        Session::regenerateId();

        return true;
    }

    /**
     * ログアウトする。
     */
    public static function logout() : void
    {
        Session::delete('admin_auth');
        Session::regenerateId();
    }

    /**
     * ログイン済みか判定する。
     *
     * @return  boolean
     */
    public static function isLoggedin() : bool
    {
        return Session::keyExists('admin_auth');
    }

    /**
     * 管理者ユーザーIDを取得する。
     *
     * @return  string
     */
    public static function getAdminUserId() : string
    {
        return Session::keyExists('admin_auth.admin_user_id') ? Session::get('admin_auth.admin_user_id') : '';
    }

    /**
     * ログインIDを取得する。
     *
     * @return  string
     */
    public static function getLoginId() : string
    {
        return Session::keyExists('admin_auth.login_id') ? Session::get('admin_auth.login_id') : '';
    }

    /**
     * メールアドレスを取得する。
     *
     * @return  string
     */
    public static function getEmail() : string
    {
        return Session::keyExists('admin_auth.email') ? Session::get('admin_auth.email') : '';
    }

    /**
     * 名前を取得する。
     *
     * @return  string
     */
    public static function getName() : string
    {
        return Session::keyExists('admin_auth.name') ? Session::get('admin_auth.name') : '';
    }

    /**
     * ロールを取得する。
     *
     * @return  string
     */
    public static function getRole() : string
    {
        return Session::keyExists('admin_auth.role') ? Session::get('admin_auth.role') : '';
    }

    /**
     * ステータスを取得する。
     *
     * @return  string
     */
    public static function getStatus() : string
    {
        return Session::keyExists('admin_auth.status') ? Session::get('admin_auth.status') : '';
    }

}

