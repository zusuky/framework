# Tips - Docker操作
よく使うdocker-composeコマンドを記載。



■ コンテナ起動

```
> docker-compose up -d
```



■ コンテナ起動（Dockerfile or ビルド処理の変更を反映させる）

```
> docker-compose up -d --build
```



■ コンテナ終了（コンテナ・ネットワーク削除）

```
> docker-compose down
```



■ コンテナ終了（コンテナ・ネットワーク・イメージ削除）

```
> docker-compose down --rmi all
```



■ コンテナ終了（コンテナ・ネットワーク・イメージ削除・ボリューム削除）

```
> docker-compose down --rmi all --volumes
```



 ■ コンテナ一覧の表示

```
> docker-compose ps
```



■ コンテナに入る

```
> docker-compose exec {コンテナ名} {コマンド}
```

※MySQLコンテナ以外は、dockerイメージが軽いalpine linuxを使用しているため{コマンド}は"ash"。
※MySQLコンテナは、alpine linuxの公式イメージがないため、{コマンド}は"bash"。
※git bashにてdocker-compose execする時は、以下のようにwinptyを付けないとエラーになる。

```
> winpty docker-compose exec {コンテナ名} {コマンド}
```



■ ログ確認
コンテナが起動しない、とか、コンテナが勝手に停止してしまう、といった時にログを見ると良い。

```
> docker-compose logs -f --tail="50"
```

