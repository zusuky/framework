#  WEB開発環境構築
以下の環境を、開発端末に構築する手順を記載する。

| ミドルウェア| バージョン | 備考 |
| ------------- | ------------- | ------------- |
| nginx | 1.17.9 | |
| MySQL | 8.0.19 | 開発端末に既にMySQLがインストールされている場合を考慮し、<br>開発端末（HOST）からのアクセスが63306ポートになるように設定する） |

<br>

| 言語| バージョン | 備考 |
| ------------- | ------------- | ------------- |
| PHP | 7.4 | |

<br>

| フレームワーク| バージョン | 備考 |
| ------------- | ------------- | ------------- |
| Zusuky | Latest | |

<br>

## 1. 前提条件
開発環境ではDockerを使用するため、以下が必要。<br>

* Hyper-Vが有効化されていること
* Docker for Windowsがインストールされていること

参考<br>
https://ops.jig-saw.com/tech-cate/docker-for-windows-install

<br>

## 3. dockerコンテナ起動

### 3-1. Windows Pewershell起動
Windows Pewershellを起動し、webディレクトリへ移動する。


### 3-2. dockerコンテナ起動


```
> docker-compose up -d
```

### 3-3. コンテナ起動確認

```
> docker-compose ps
```

以下のように3つのコンテナ（nginx、php、mysql）がUpになればOK。

```
  Name                Command              State            Ports
--------------------------------------------------------------------------
nginx   nginx -g daemon off;            Up      0.0.0.0:80->80/tcp
php     docker-php-entrypoint php-fpm   Up      9000/tcp
mysql   docker-entrypoint.sh mysqld     Up      0.0.0.0:63306->3306/tcp, 33060/tcp

```

<br>

## 4. Zusukyセットアップ（初回、または、Dockerファイルを弄った時）

### 4-1. Windows Pewershell起動
Windows Pewershellを起動し、webディレクトリへ移動する。


### 4-2. phpコンテナに入る

```
> docker-compose exec php ash
```
※Windows Pewershellではなく、git bashでコンテナに入るときは、以下のようにwinptyを付けないとエラーになるので注意。

```
> winpty docker-compose exec php ash
```

### 4-3. Zusukyインストール（初回、または、Dockerファイルを弄った時）
※インストールが終われば、vendorディレクトリが生成される。


```
/var/www # composer install
```

### 4-4. Zusukyの基本構成に応じたディレクトリの作成（初回のみ）
```
/var/www # sh project_initialize.sh
```

実行することで、appディレクトリ、configディレクトリ、appディレクトリが生成される。

また、local実行用のconfigファイルが生成される。

### 4-5.  phpコンテナからexit

```
/var/www # exit
```

<br>

## 5. DB接続確認
DBクライアントツールなどで、ポート63306にて接続しDBにアクセスできればOK。

<br>

## 6. サイト表示確認
以下のURLにアクセスし、サイトが表示されればOK。<br>

```
http://localhost
http://localhost/admin/
```

<br>

## 7. ログ、データファイルなど
ログやデータファイルは、ホストマシンとコンテナで共有している。
共有しているファイルは、sharedフォルダ配下に作成される。

### ホストマシン上で確認する場合
sharedディレクトリ配下を確認すればOK。

### コンテナ上で確認する場合
各コンテナに入り、それぞれのコンテナ上で確認する。
docker-compose.ymlのvolumesを見れば、ホストマシン上と、コンテナ上での対比がわかるはず。

<br>

## 8. 注意
Zusukyのログ出力はlog4phpを使用しているが、log4phpの設定が完了していない状態でエラーが発生すると、
nginxのerror.logにログが出力される。そちらを確認してみると、原因が判るかもしれない。



## 9. sass, jsのコンパイル

cssはsassで管理する方がよい。（デザインのテンプレート化がし易い。）

jsも圧縮した方がよい。

Zusukyでは、実際に使用されるcss, jsはpublicディレクトリ配下のものだが、

appディレクトリの配下にresourcesディレクトリがあり、コンパイル前のsassやjsを記述できるようになっている。

開発の際は、resources配下でsassやjsに変更を行い、コンパイルしてpublicディレクトリ配下に出力する方がよいであろう。

以下を行うことで、sassやjsを自動コンパイルすることができる。

### 9-1. Windows Pewershell起動

Windows Pewershellを起動し、webディレクトリへ移動する。

### 9-2. phpコンテナに入る

```
> docker-compose exec php ash
```

### 9-3. npmで必要パッケージインストール

```
/var/www # npm ci
```

入れたいのはlaravel-mix。

入れば、node_modulesディレクトリが生成される。

※Python絡みのエラーは、出ても無視してOK。

### 9-4. sass, jsの変更監視

```
/var/www # npm run watch
```

上記を実行しておけば、変更を監視し、自動的にコンパイルしてくれる。

コンパイル元ファイル、コンパイル先ファイルの定義は「webpack.mix.js」参照。