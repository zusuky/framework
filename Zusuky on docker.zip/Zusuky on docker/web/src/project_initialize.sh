#!/bin/sh

cp -r /var/www/vendor/zusuky/framework/app /var/www/
cp -r /var/www/vendor/zusuky/framework/public /var/www/
cp -r /var/www/vendor/zusuky/framework/config /var/www/
rm -f /var/www/vendor/zusuky/framework/config/*.php
rm -f /var/www/vendor/zusuky/framework/config/*.properties
cp /var/www/config/local_sample/local.config.admin.php /var/www/config/config.admin.php
cp /var/www/config/local_sample/local.config.front.php /var/www/config/config.front.php
cp /var/www/config/local_sample/local.log4php.properties /var/www/config/log4php.properties